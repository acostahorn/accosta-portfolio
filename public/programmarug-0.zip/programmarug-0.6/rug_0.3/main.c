/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * main.c
 * Copyright (C) 2015 alberto <alberto@alberto-pc>
 *
 * RUG-III-0.3 is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * RUG-III-0.3 is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ncurses.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

struct stat st = {0};


struct fecha
{
    int giorno;
    int mese;
    int anno;
};

struct rug
{
	char nome [20];
	char cognome [20];
	bool sesso;
	struct fecha nascita;
	struct fecha ingresso;
	struct fecha valutazione;
	bool tempor;
	char codice_fiscale [17];
	char annotazioni [300];
	char malattie [300];

	short rug [4] ;

	// SEZIONE B

	short cognitivo [3];

	// SEZIONE C

	short comprensione;

	//SEZIONE E ultimi 15 giorni

	short umore [16];

	//SEZIONE E ultimi 7 giorni

	short comportamento [5][2];

	//SEZIONE G

	short adl [4][2];

	//SEZIONE H

	bool continenza [2];

	//SEZIONE I

	bool diagnosi1 [6];

	//SEZIONE J

	bool problemi [7];

	//SEZIONE K

	short nutrizione [5];

	//SEZIONE M

	short cute [19];

	//SEZIONE N

	bool attivita [3];

	//SEZIONE O

	short iniezioni;

	//SEZIONE P

	bool trattamenti [9];
	short terapie [4][2];
	short riabilitazione [10];
	short visite;
	short prescrizioni;

	//SEZIONE I bis

	bool diagnosi2 [16];

	//SEZIONE J bis

	bool incidenti [4];

	//SEZIONE M bis

	bool guarigioni;

	//SEZIONE P bis

	short contenzione [5];
	short degenze;
	short dea;
	bool esami;






};

struct coord
{
 int x;
 int y;
};

static char letti[32][4]={"11","12","13a","13b","13c","14a","14b","14c","15","16a","16b",
	"16c","20","21","22","23","24","25a","25b","26a","26b","27","31a","31b","32",
	"33","34","35a","35b","36a","36b","37"};

static char romani [5][4]={"-  ","I  ","II ","III","IV "};

static char decisioni [5][40]= {"0. Indipendente","1. Compromissione lieve","2. Compromissione moderata","3. Compromissione severa","4. Non determinabile"};

static char comun [5][30]={"0. Compreso","1. In genere compreso","2. Talvolta compreso","3. Raramente - Mai compreso","4. N/A                   "};




static struct rug archivio;
static FILE *h;
static char stringa [] = "archivio  .dat";
static short s=3;
static char ch;


void create_arch(int i);
void load_arch(int i);
void save_arch(int i);
void show_paz (int i);

void edit_arch(int i);
void dim_paz(int i);
char *strinp (void);
int inpt (void);
int inpnum (int n);


void anagrafica (int i);
void cognitivo (int i);
void comprensione (int i);
void umore (int i);
void comportamento (int i);
void adl (int i);
void continenza (int i);
void diagnosi1 (int i);
void problemi (int i);
void nutrizione (int i);
void cute (int i);
void attivita (int i);
void iniezioni (int i);
void speciali (int i);
void diagnosi2(int i);
void incidenti (int i);
void guarigioni (int i);
void speciali2 (int i);
void calcolarug (int i);

bool categ1 (int adl);
bool riab (void);

bool special_care (int adl);
bool clinic_complex (int adl);
bool impaired_cogn (int adl);
bool behavior (void);

short skin_treatments ();
short nursing_rehab ();

void save_text(int i);
char *classif (void);

struct coord griglia(int x0, int y0, int xpart, int ypart, int xsize,int ysize,int xmax,int ymax);

/** PROGRAMMA PRINCIPALE **/

int main()
{

if (stat("dimessi", &st) == -1)
{
    mkdir("dimessi", 0700);
}
if (stat("text", &st) == -1)
{
    mkdir("text", 0700);
}

	int i;
	char c;
	short a,b;

	initscr ();
	raw ();
	keypad (stdscr, TRUE);
	noecho ();

	for (i=0; i<32; i++)
	{

        a=(i+1)/10;
        b=(i+1)%10;
        *(stringa+8)= 48+a;
        *(stringa+9)= 48+b;
		h =fopen (stringa,"r");

		if (h==NULL)
		{
            clear ();
    		printw("\nelemento %d inesistente!",i);
    		create_arch(i);
			refresh ();
			getch();


		} else fclose (h);
	}





    refresh ();



    int x,y;



    do
    {
    x=0;
    y=2;


    c=0;


    clear ();

    printw("RESIDENZA BOCCADASSE - PROGRAMMA RUG-III versione 0.3-2016\n\n");


    for(i=0;i<32;i++)
    {
		load_arch (i);
		if (i==16)
		{
            x=x+44;
            y=2;
        }
        move (y,x);
        printw("#%d\tLetto %s\t: %s %c.\n",i+1,letti[i],archivio.cognome,
               archivio.nome[0]);
        y++;
    }

    printw ("\n\n<-a  | s  A w  d->   x=dimetti ospite\tq=esci\n     V    |\n");
    printw ("* = stampa la scheda in un file di testo");
    refresh();
    cbreak();

    y=2;
    x=0;
    i=0;


    move (y,x);


    while (c!='\n')
    {
    c=getch();

    if (c=='s')
        i++;

    if (c=='w')
        i--;
    if ((c=='d')&&(i<16))
     i+=16;
     if ((c=='a')&&(i>15))
     i-=16;

    if (i<0)
        i=31;
    if (i==32)
        i=0;

    if (i<16)
    {
        y=i+2;
        x=0;
        }
    if (i>15)
    {
        y=i-14;
        x=44;
        }
    move (y,x);
    if (c=='q')
        break;
    if (c=='x')
        break;
    if (c=='*')
        break;

    refresh ();
    }

    clear();
    if (c=='\n')
    {
    load_arch(i);
    edit_arch(i);
    }
	refresh();

	if (c=='x')
	{
	load_arch(i);
	dim_paz(i);
	}

	if (c=='*')
	{
	load_arch(i);
	save_text(i);
	}


	} while (c!='q');

    endwin();



    return 0;
}



void create_arch(int i)
{
    printw("\ncreazione archivio\n");
    strcpy(archivio.nome,"---");
    strcpy(archivio.cognome,"---");
    archivio.sesso =0;
    archivio.nascita.giorno =0;
    archivio.nascita.mese=0;
    archivio.nascita.anno=0;
    archivio.ingresso.giorno =0;
    archivio.ingresso.mese=0;
    archivio.ingresso.anno=0;
    archivio.valutazione.giorno =0;
    archivio.valutazione.mese=0;
    archivio.valutazione.anno=0;
    archivio.tempor=0;
    strcpy(archivio.codice_fiscale,"---");
    strcpy(archivio.annotazioni,"---");
    strcpy(archivio.malattie,"---");



    int j,k;

    for (j=0;j<4;j++)
        archivio.rug [j] = 0;


	for (j=0;j<3;j++)
        archivio.cognitivo [j] = 0;


    archivio.comprensione=0;

    for (j=0;j<16;j++)
        archivio.umore [j] = 0;

    for (j=0;j<5;j++)
    {
        for (k=0;k<2;k++)
        archivio.comportamento [j][k] = 0;
    };

    for (j=0;j<4;j++)
    {
        for (k=0;k<2;k++)
        archivio.adl [j][k] = 0;
    };


     archivio.continenza [0]=0;
     archivio.continenza [1]=0;


    for (j=0;j<6;j++)
        archivio.diagnosi1 [j] = 0;

    for (j=0;j<7;j++)
        archivio.problemi [j] = 0;

    for (j=0;j<16;j++)
        archivio.nutrizione [j] = 0;

    for (j=0;j<19;j++)
        archivio.cute [j] = 0;

    for (j=0;j<3;j++)
        archivio.attivita [j] = 1;

    archivio.iniezioni=0;

    for (j=0;j<9;j++)
        archivio.trattamenti [j] = 0;

    for (j=0;j<4;j++)
    {
        for (k=0;k<2;k++)
        archivio.terapie [j][k] = 0;
    };

    for (j=0;j<10;j++)
        archivio.riabilitazione [j] = 0;

    archivio.visite =0;
    archivio.prescrizioni =0;

    for (j=0;j<16;j++)
        archivio.umore [j] = 0;

    for (j=0;j<16;j++)
        archivio.diagnosi2 [j] = 0;

    for (j=0;j<4;j++)
        archivio.incidenti [j] = 0;

    archivio.guarigioni=0;

    for (j=0;j<5;j++)
        archivio.contenzione [j] = 0;

    archivio.degenze=0;
    archivio.dea=0;
    archivio.esami=0;



    save_arch(i);
}



void show_paz (int i)
{
    char copia [70];
    strncpy (copia,archivio.malattie,70);
    copia [70]=0;
	printw("#%d\tLetto %s\t: %s\t%s\nDiagnosi: %s\n",i+1,letti[i],archivio.cognome,
               archivio.nome, copia);
    //if (!archivio.rug)
    //    printw ("Scheda RUG non compilata");
	refresh ();
}


void edit_arch(int i)
{

    char c=0;
    load_arch (i);
    while (c!='q')
    {
    clear ();
    show_paz (i);

    move (3,0);

    printw ("AA.\tAnagrafica\nB.\tStato Cognitivo\nC.\tComprensione\n");
    printw ("E1.\tUmore (ultimi 15 giorni)\nE2.\tComportamento (ultimi 7 giorni)\nG.\tADL\n");
    printw ("H.\tContinenza\nI1.\tDiagnosi (1)\nJ1.\tProblemi\nK.\tNutrizione\nM1.\tCute\n");
    printw ("N.\tAttivita'\nO.\tIniezioni\nP1.\tTrattamenti speciali (1)\nI2.\tDiagnosi (2)\n");
    printw ("J2.\tIncidenti\nM2.\tGuarigioni\nP2.\tTrattamenti speciali (2)\n");
    printw ("*.\tATTRIBUZIONE FASCIA RUG-III");

    refresh();




   do
    {
        move (s,0);
        c=getch();
        if (c=='s')
            s++;
        if (c=='w')
            s--;
        if (s==22)
            s=3;
        if (s==2)
            s=21;

    } while ((c!='\n')&&(c!='q'));

    if (c=='q')
        break;

    switch (s)
    {
        case 3:
        anagrafica (i);
        break;

        case 4:
        cognitivo (i);
        break;

        case 5:
        comprensione (i);
        break;

        case 6:
        umore (i);
        break;

        case 7:
        comportamento (i);
        break;

        case 8:
        adl (i);
        break;

        case 9:
        continenza (i);
        break;

        case 10:
        diagnosi1 (i);
        break;

        case 11:
        problemi (i);
        break;

        case 12:
        nutrizione (i);
        break;

        case 13:
        cute (i);
        break;

        case 14:
        attivita (i);
        break;

        case 15:
        iniezioni (i);
        break;

        case 16:
        speciali (i);
        break;

        case 17:
        diagnosi2 (i);
        break;

        case 18:
        incidenti (i);
        break;

        case 19:
        guarigioni(i);
        break;

        case 20:
        speciali2 (i);
        break;

        case 21:
        calcolarug (i);
        break;




    }
    /** ARE YOU SURE?? **/
    save_arch (i);

    }





}


void save_arch(int i)
{
    short a,b;
    a=(i+1)/10;
    b=(i+1)%10;
	*(stringa+8)= 48+a;
	*(stringa+9)= 48+b;

    h=fopen(stringa,"w");
    fwrite(&archivio,sizeof(struct rug),1,h);
    fclose(h);
}

void load_arch(int i)
{
	short a,b;
    a=(i+1)/10;
    b=(i+1)%10;
	*(stringa+8)= 48+a;
	*(stringa+9)= 48+b;


    h=fopen(stringa,"r");
    fread(&archivio,sizeof(struct rug),1,h);
    fclose(h);
}

void dim_paz(int i)

{
    show_paz (i);
    printw("\nSicuro che deve essere dimesso?S/N");
    char c=0;
    while ((c!='s')&&(c!='n'))
        c=getch();
    if (c=='n')
        return;

    else

    {
    char destination [30];
    int k;
    short l;

    strcpy (destination,"dimessi/");

    l=strlen(archivio.cognome);

    for (k=0;k<l;k++)
        destination [k+8]=archivio.cognome[k];
    destination [l+8]='.';
    destination [l+9]='d';
    destination [l+10]='a';
    destination [l+11]='t';
    destination [l+12]=0;
    h=fopen (destination,"w");
    fwrite(&archivio,sizeof(struct rug),1,h);
    fclose (h);

    create_arch(i);
    save_arch(i);
    }




}

char *strinp (void)
{
    echo ();
    char *stg = malloc (sizeof(char)*300);

    getstr (stg);
    noecho ();

    return stg;
}

int inpt (void)
{
	int num = 0;
	echo();
	while (num<1 || num>32)
		scanw ("%d",&num);
    noecho();
	return num;
}

int inpnum (int n)
{
int numero=0;
	int k,l;
	int base=1;
	int j[n];

for (k=0;k<n;k++)
	j[k]=0;

	char c=0;




for (k=0;k<n;k++)
{
	do
 	{
		c=getch();
		if ((c=='\n')&&(k>0))
			break;
	} while ((c<48)||(c>59));

	if ((c=='\n')&&(k>0))
	{

		break;
    }

	else
	{
		addch (c);
		j[k]=c-48;
	}


}

for (l=0;l<k;l++)
{
	numero=numero+j[n-l-1]*base;
	base=base*10;

}
return (numero);
}

void anagrafica (int i)
{
    char c=0;
    char sex;
    int s=3;
    char d;

    while (c!='q')
    {
    clear ();


    printw ("#%d    Letto:%s\nSEZIONE AA Anagrafica\n\nNome:\t\t%s\nCognome:\t%s\nSesso:\t",i+1,letti[i],archivio.nome,archivio.cognome);
    if (!archivio.sesso)
        addch ('F');
    else
        addch ('M');
    printw ("\nData di nascita:\t%2d/%2d/%4d",archivio.nascita.giorno,archivio.nascita.mese,archivio.nascita.anno);
    printw ("\nData di ingresso:\t%2d/%2d/%4d",archivio.ingresso.giorno,archivio.ingresso.mese,archivio.ingresso.anno);
    printw ("\nData di valutazione:\t%2d/%2d/%4d\n",archivio.valutazione.giorno,archivio.valutazione.mese,archivio.valutazione.anno);
    if (!(archivio.tempor))
        printw ("Inserimento definitivo\n");
    else
        printw ("Inserimento temporaneo\n");
    printw ("Codice Fiscale:\t%s\n",archivio.codice_fiscale);
    printw ("Annotazioni:\t%s\n\n\n",archivio.annotazioni);
    printw ("Diagnosi di ingresso:\t%s",archivio.malattie);
    do
    {
        move (s,0);
        c=getch();
        if ((c=='s')&&(s<13))
        {if (s>10)
            s=s+3;
        else
            s++;
        }
        if ((c=='w')&&(s>3))
        {if (s==14)
            s=s-3;
        else
            s--;
        }

    }while ((c!='\n')&&(c!='q'));

    refresh();

    if (c=='q')
        break;
    switch (s)
    {
        case 3:
        move (3,16);
        strcpy (archivio.nome,strinp());
        break;

        case 4:
        move (4,16);
        strcpy (archivio.cognome,strinp());
        break;

        case 5:


        sex=0;
        move (5,8);
        while ((sex!='m')&&(sex!='f'))
            sex=getch();
        if (sex=='f')
            archivio.sesso=0;
        else
            archivio.sesso=1;


        break;

        case 6:
        do
        {
        move (6,24);
        archivio.nascita.giorno=inpnum (2);
        } while  ((archivio.nascita.giorno>32)||(archivio.nascita.giorno<1));
        do
        {
        move (6,27);
        archivio.nascita.mese=inpnum (2);
        } while ((archivio.nascita.mese>12)||(archivio.nascita.mese)<1);
        do
        {
        move (6,30);
        archivio.nascita.anno=inpnum(4);
        } while (archivio.nascita.anno<1860);

        break;

        case 7:
        do
        {
        move (7,24);
        archivio.ingresso.giorno=inpnum (2);
        } while  ((archivio.ingresso.giorno>32)||(archivio.ingresso.giorno<1));
        do
        {
        move (7,27);
        archivio.ingresso.mese=inpnum (2);
        } while ((archivio.ingresso.mese>12)||(archivio.ingresso.mese)<1);
        do
        {
        move (7,30);
        archivio.ingresso.anno=inpnum(4);
        } while (archivio.ingresso.anno<2005);

        break;

        case 8:
         {
        move (8,24);
        archivio.valutazione.giorno=inpnum (2);
        } while  ((archivio.valutazione.giorno>32)||(archivio.valutazione.giorno<1));
        do
        {
        move (8,27);
        archivio.valutazione.mese=inpnum (2);
        } while ((archivio.valutazione.mese>12)||(archivio.valutazione.mese)<1);
        do
        {
        move (8,30);
        archivio.valutazione.anno=inpnum(4);
        } while (archivio.valutazione.anno<2005);


        break;

        case 9:
         do
        {
        move (9,12);

        d=getch ();
        if ((d=='w')||(d=='s'))
            archivio.tempor=!(archivio.tempor);
        if (!(archivio.tempor))
        printw ("definitivo\n");
        else
        printw ("temporaneo\n");

        } while (d!='\n');
        break;

        case 10:
        move (10,16);
        strncpy (archivio.codice_fiscale,strinp(),16);
        archivio.codice_fiscale [16]=0;
        break;

        case 11:
        move (11,16);
        strcpy (archivio.annotazioni,strinp());
        break;

        case 14:
        move (14,24);
        strcpy (archivio.malattie,strinp());
    }

    }

}

void cognitivo(int i)

{
    char c,d;
    short s=3;


    while (c!='q')
{

    clear ();
    printw ("#%d    Letto:%s %s %s\nSEZIONE B Stato Cognitivo\n\n",i+1,letti[i],archivio.cognome,archivio.nome);
    printw ("1.Stato di coma:\t");
    if (archivio.cognitivo [0]==1)
        printw ("SI\n\n");
    else
        printw ("NO\n\n");
        printw ("2.Memoria a breve termine (dopo 5 minuti):\t");
        if (!(archivio.cognitivo[1]))
            printw ("OK");
        else
        {
        if (archivio.cognitivo[1]==1)
            printw ("Problemi di memoria");
        else
            printw ("Non determinabile");

        }

        printw("\n\n4.Capacita' di prendere decisioni:\t\t");

        printw ("%s",decisioni[archivio.cognitivo[2]]);



    move (3,0);

    do
    {
        move (s,0);
        c=getch();
        if ((c=='s')&&(s<7))
            s+=(2*!(archivio.cognitivo[0]));
        if ((c=='w')&&(s>3))
            s-=(2*!(archivio.cognitivo[0]));

    } while ((c!='\n')&&(c!='q'));

    if (c=='q')
        break;

    switch (s)
    {
        case 3:
         do
        {
        move (3,24);

        d=getch ();
        if ((d=='w')||(d=='s'))
            archivio.cognitivo[0]=!(archivio.cognitivo[0]);
        if (archivio.cognitivo[0])
        {
        printw ("SI\n");
        archivio.cognitivo [1]=2;
        archivio.cognitivo [2]=4;
        }

        else
        printw ("NO\n");

        } while (d!='\n');
        break;

        case 5:
        do
        {
        move (5,48);

        d=getch ();
        if ((d=='w')&&(archivio.cognitivo[1]<2))
            archivio.cognitivo[1]++;
        if ((d=='s')&&(archivio.cognitivo[1]>0))
            archivio.cognitivo[1]--;

         if (!(archivio.cognitivo[1]))
            printw ("OK                 ");
        else
        {
        if (archivio.cognitivo[1]==1)
            printw ("Problemi di memoria");
        else
            printw ("Non determinabile  ");
        }



        } while (d!='\n');
        break;

        case 7:

        do
        {
        move (7,48);
        d=getch();
        if ((d=='w')&&(archivio.cognitivo[2]<4))
            archivio.cognitivo [2]+=1;
        if ((d=='s')&&(archivio.cognitivo[2]>0))
            archivio.cognitivo [2]-=1;
        printw ("%s        ",decisioni[archivio.cognitivo[2]]);


        } while (d!='\n');
        break;






}
}
}

void comprensione(int i)
{
    char c;


    char comun [5][30]={"0. Compreso","1. In genere compreso","2. Talvolta compreso","3. Raramente - Mai compreso","4. N/A                   "};


    clear ();
    printw ("#%d    Letto:%s %s %s\nSEZIONE C COMUNICAZIONE - SFERA UDITIVA\n\n",i+1,letti[i],archivio.cognome,archivio.nome);

    printw ("4.\tCapacità di esprimere comunque il contenuto delle informazioni negli\n\tultimi 7 giorni: %s",comun[archivio.comprensione]);

    do
    {
        move (4,25);
        c=getch();
        if ((c=='w')&&(archivio.comprensione<4))
            archivio.comprensione+=1;
        if ((c=='s')&&(archivio.comprensione>0))
            archivio.comprensione-=1;
        printw ("%s           ",comun[archivio.comprensione]);

    }   while (c!='q');



}

void umore (int i)
{
    char c,d;
    short j;
    short k=5;
    short l=0;
    short y;

    while (1)
    {

    clear ();
    printw ("#%d    Letto:%s %s %s\nSEZIONE E parte 1:UMORE negli ultimi 15 giorni\n",i+1,letti[i],archivio.cognome,archivio.nome);
    printw ("(0 non mostrato, 1 fino a cinque giorni/sett. 2 giornalmente)\n\nESPRESSIONI DI MALESSERE\n");

    printw ("a.affermazioni negative\nb.domande ripetitive\nc.ripetute richieste di aiuto\nd.rabbia o irritabilità\ne.autodisistima\nf.espressione di paure non reali");
    printw ("\ng.l'ospite afferma in modo ricorrente l'imminenza di un evento terribile\n");
    printw ("h.ripetute lamentele rispetto alla propria salute\n");
    printw ("i.manifestazioni ripetute di ansia\n");
    printw ("PROBLEMI CON IL SONNO\n");
    printw ("j.cattivo umore la mattina\nk.insonnia - cambiamenti del normale ciclo del sonno\n");
    printw ("ATTEGGIAMENTO TRISTE, APATICO, ANSIOSO");
    printw ("\nl.espressione del volto triste, addolorata, preoccupata");
    printw ("\nm.pianto, facilità alle lacrime");
    printw ("\nn.movimenti ripetitivi");
    printw ("\nPERDITA D'INTERESSE");
    printw ("\no.astensione da attività interessanti");
    printw ("\np.ridotte interazioni sociali");

    y=5;

    for (j=0;j<16;j++)
    {
    if ((y==14)||(y==17)||(y==21))
        y++;
    mvprintw (y,75,"%d",archivio.umore[j]);
    y++;
    }



    do
    {
        move (k,0);

        c=getch();
        if ((c=='s')&&(k<23))
        {
            k=k+((k==13)||(k==16)||(k==20))+1;
            l++;
        }

        if ((c=='w')&&(k>5))
        {
            k=k-((k==22)||(k==18)||(k==15))-1;
            l--;
        }





        if (c=='q')
            break;
    } while (c!='\n');

    if (c=='q')
        break;



    do
    {
        move (k,75);
        d=getch();
        if ((d=='w')&&(archivio.umore[l]<2))
            archivio.umore[l]++;
        if ((d=='s')&&(archivio.umore[l]>0))
            archivio.umore[l]--;

        printw ("%d",archivio.umore[l]);

    } while (d!='\n');

}

}

void comportamento (int i)

{
char c,d;
    short j;

    short y=10;
    short x=0;

    while (1)
    {

    clear ();
    printw ("#%d    Letto:%s %s %s\nSEZIONE E parte 2: COMPORTAMENTO negli ultimi 7 giorni\n",i+1,letti[i],archivio.cognome,archivio.nome);
    printw ("A Frequenza dei problemi\n(0 non mostrato, 1= da 1 a 3 gg./sett. 2= da 4 a 6 gg/sett., 3= quotidianamente)\n");
    printw ("B Possibilità di modificare i problemi negli ultimi 7 giorni\n(0 problema assente o modificabile, 1 problema difficilmente modificabile");
    printw ("\n\n\t\t\t\t\t\t\tA\t\tB\n\n");
    printw ("a.VAGARE senza motivo, incurante della sicurezza\n");
    printw ("b.USARE LINGUAGGIO OFFENSIVO\n");
    printw ("c.ESSERE FISICAMENTE AGGRESSIVO\n");
    printw ("d.COMPORTAMENTO SOCIALMENTE INADEGUATO\n");
    printw ("e.RIFIUTARE L'ASSISTENZA");



    for (j=0;j<5;j++)
    {
        mvprintw (j+10,56,"%d",archivio.comportamento[j][0]);
        mvprintw (j+10,72,"%d",archivio.comportamento[j][1]);
    }

    do
    {
        move (y,56+x*16);
        c=getch();
        if (c=='q')
            break;
        if ((c=='s')&&(y<14))
            y++;
        if ((c=='w')&&(y>10))
            y--;

            x=x+((c=='d')&&(!x));
            x=x-((c=='a')&&(x));

    } while (c!='\n');

    if (c=='q')
        break;

    do
    {
    move (y,56+16*x);
    d=getch ();
    if ((d=='w')&&(archivio.comportamento[y-10][x])<3-2*x)
        archivio.comportamento[y-10][x]++;
    if ((d=='s')&&(archivio.comportamento[y-10][x])>0)
        archivio.comportamento[y-10][x]--;
    printw ("%d",archivio.comportamento[y-10][x]);


    } while (d!='\n');

}

}

void adl (int i)

{
char d;
    short j;

    struct coord a;
    a.x=0;
    a.y=0;


    while (1)
    {

    clear ();
    printw ("#%d    Letto:%s %s %s\nSEZIONE G: FUNZIONE FISICA E PROBLEMI RELATIVI ALLA STRUTTURA\nnegli ultimi 7 giorni - 7 notti\n\n",i+1,letti[i],archivio.cognome,archivio.nome);
    printw ("A Autonomia nelle ADL: 0 indipendente, 1 supervisione, 2 assistenza limitata,\n3 assistenza intensiva, 4 dipendenza totale, 8 attività mai eseguita\n");
    printw ("B Aiuto fornito nelle ADL: 0 nessuno, 1 solo organizzazione, 2 aiuto fisico (1 persona), 3 aiuto fisico (2 persone), 8 attività mai eseguita");
    printw ("\n\n\t\t\t\t\t\t\tA\t\tB\n\n");
    printw ("a.MOBILITA' A LETTO\n");
    printw ("b.TRASFERIMENTI\n");
    printw ("h.MANGIARE\n");
    printw ("i.ELIMINAZIONE DI FECI ED URINE\n");



    for (j=0;j<4;j++)
    {
        mvprintw (j+11,56,"%d",archivio.adl[j][0]);
        mvprintw (j+11,72,"%d",archivio.adl[j][1]);
    };


   a=griglia(56,11,a.x,a.y,16,1,1,3);





    if (ch=='q')
        break;


    do
    {
    move (11+a.y,56+16*a.x);
    d=getch ();
    if ((d=='w')&&(archivio.adl[a.y][a.x])<8)
    {

        archivio.adl[a.y][a.x]=archivio.adl[a.y][a.x]+1;
        if (archivio.adl[a.y][a.x]==(5-a.x))
            archivio.adl[a.y][a.x]=8;


    }


    if ((d=='s')&&(archivio.adl[a.y][a.x])>0)
    {
        if (archivio.adl[a.y][a.x]==8)
            archivio.adl[a.y][a.x]=4-a.x;
        else
        archivio.adl[a.y][a.x]--;

    }

    if (archivio.cognitivo[0])
    {
        for (j=0;j<4;j++)
        {
            if (archivio.adl[j][0]<4)
                archivio.adl[j][0]=4;
            if (archivio.adl[j][1]<2)
                archivio.adl[j][1]=2;
        }

    }

    printw ("%d",archivio.adl[a.y][a.x]);


    } while (d!='\n');

}

}

void continenza (int i)

{
    char d;
    int j;
    int y=0;



    while (1)
    {
        clear ();
        printw ("#%d    Letto:%s %s %s\nSEZIONE H: CONTINENZA FECALE ED URINARIA negli ultimi 7 giorni\n",i+1,letti[i],archivio.cognome,archivio.nome);
        mvprintw (9,0,"3a.Ospite accompagnato al bagno ad intervalli regolari,\nin base a un programma definito:\n\n3b.Programmi di rieducazione vescicale:");
        for (j=0;j<2;j++)
        {
            move (10+2*j,70);
            if (!(archivio.continenza[j]))
                printw ("NO");
            else
                printw ("SI");
        }


    y=griglia(70,10,0,y,2,2,0,1).y;

    if (ch=='q')
        break;

    do
    {
        move (10+2*y,70);
      d=getch();
      if ((d=='w')||(d=='s'))
            archivio.continenza[y]=!(archivio.continenza[y]);

            if (!(archivio.continenza)[y])
                printw ("NO");
            else
                printw ("SI");
    } while (d!='\n');


    }

}

void diagnosi1 (int i)

{
    char d;
    int j;
    int y=0;

    while (1)
    {
        clear ();
        printw ("#%d    Letto:%s %s %s\nSEZIONE I: DIAGNOSI DI MALATTIA negli ultimi 14 giorni\n",i+1,letti[i],archivio.cognome,archivio.nome);
        printw ("Segnare solo malattie in relazione con: ADL, stato cognitivo, umore,\ncomportamento, terapie mediche, monitoraggio infermieristico, rischio di morte\nnegli ultimi 14 giorni");

        mvprintw (9,0,"a. Diabete Mellito\n\nr. Afasia\n\ns. Cerebropatia o epilessia - NB escluse demenze, Alzheimer, ictus\n\n");
        printw ("v. Emiplegia, emiparesi\n\nw. Sclerosi multipla\n\nz. Tetraplegia");

       for (j=0;j<6;j++)
        {
            move (9+2*j,70);
            if (!(archivio.diagnosi1[j]))
                printw ("NO");
            else
                printw ("SI");
        }


    y=griglia(70,9,0,y,2,2,0,5).y;


    if (ch=='q')
        break;

    do
    {
        move (9+2*y,70);
      d=getch();
      if ((d=='w')||(d=='s'))
            archivio.diagnosi1[y]=!(archivio.diagnosi1[y]);

            if (!(archivio.diagnosi1)[y])
                printw ("NO");
            else
                printw ("SI");
    } while (d!='\n');


    }

}

void problemi (int i)

{
    char d;
    int j;
    int y=0;

    while (1)
    {
        clear ();
        printw ("#%d    Letto:%s %s %s\nSEZIONE J1: PROBLEMI DI SALUTE negli ultimi 7 giorni\n",i+1,letti[i],archivio.cognome,archivio.nome);
        move (4,0);
       printw("1c.Segni di disidratazione. Almeno 2 dei seguenti indicatori:---------\n");
       printw("   assunzione <2500cc di liquidi/die - segni clinici di disidratazione\n");
       printw("   bilancio idrico negativo\n");
       printw("1e.Episodi psicotici--------------------------------------------------\n\n\n");
       printw("1h.Febbre-------------------------------------------------------------\n\n\n");
       printw("1i.Allucinazioni------------------------------------------------------\n\n\n");
       printw("1j.Emorragia interna (ematuria,emottisi,melena,ecc.)..................\n\n\n");
       printw("1o.Vomito-------------------------------------------------------------\n\n\n");
       printw("5c.Malattia terminale con prognosi di 6 mesi o meno-------------------");

       for (j=0;j<7;j++)
        {
            move (4+3*j,73);
            if (!(archivio.problemi[j]))
                printw ("NO");
            else
                printw ("SI");
        }


    y=griglia(73,4,0,y,2,3,0,6).y;


    if (ch=='q')
        break;

    do
    {
        move (4+3*y,73);
      d=getch();
      if ((d=='w')||(d=='s'))
            archivio.problemi[y]=!(archivio.problemi[y]);

            if (!(archivio.problemi)[y])
                printw ("NO");
            else
                printw ("SI");
    } while (d!='\n');


    }

}


void nutrizione (int i)

{
    char d;
    int j;
    int y=0;

    while (1)
    {
        clear ();
        printw ("#%d    Letto:%s %s %s\nSEZIONE K: STATO NUTRIZIONALE\n",i+1,letti[i],archivio.cognome,archivio.nome);
        move (4,0);
       printw("3a.Perdita di peso del 5%% o più negli ultimi 30 giorni----------------\n");
       printw("   o del 10%% o più negli ultimi 180 giorni\n\n");
       printw("5a.Nutrizione parenterale (EV)----------------------------------------\n\n\n");
       printw("5b.Nutrizione enterale via SNG-Gastrostomia-PEG-digiunostomia---------\n\n\n");
       printw("6a.%%di calorie ricevute tramite nutrizione artificiale----------------\n");
       printw("   0. nulla - 1. 1%%-25%% - 2. 26%%-50%% - 3. 51%%-75%% - 4. 76%%-100%%\n\n");
       printw("6b.Quota di fluidi assunti per ev o sondino negli ultimi 7 gg.------------\n");
       printw("   0. nulla - 1. 1-500cc - 2. 501-1000cc - 3. 1001-1500cc\n");
       printw("   4. 1501-2000cc - 5. più di 2000cc");

       for (j=0;j<5;j++)
        {
            move (4+3*j,73);
            if (j==0)
                addch(' ');
            if (j<3)
            {
            if (!(archivio.nutrizione[j]))
                printw ("NO");
            else
                printw ("SI");
            }
            else
                printw ("%d",archivio.nutrizione[j]);
        }


    y=griglia(73,4,0,y,2,3,0,4).y;


    if (ch=='q')
        break;
    if (y<3)
    {
    do
    {
        move (4+3*y,73);
      d=getch();
      if ((d=='w')||(d=='s'))
            archivio.nutrizione[y]=!(archivio.nutrizione[y]);

            if (!(archivio.nutrizione[y]))
                printw ("NO");
            else
                printw ("SI");
    } while (d!='\n');
    }
    else
    {
    do
    {
        move (4+3*y,73);
        d=getch();
        if ((d=='w')&&(archivio.nutrizione[y]<y+1))
            archivio.nutrizione[y]++;
        if ((d=='s')&&(archivio.nutrizione[y])>0)
            archivio.nutrizione[y]--;
        printw ("%d",archivio.nutrizione[y]);
    } while (d!='\n');
    }


    }

}

void cute (int i)

{
    char d;
    int j;
    int y=0;
    short h,max_stadio;
    max_stadio=0;

    while (1)
    {
        clear ();
        printw ("#%d    Letto:%s %s %s\nSEZIONE M: CONDIZIONI DELLA CUTE negli ultimi 7 giorni",i+1,letti[i],archivio.cognome,archivio.nome);
        move (3,0);

        printw("1a.Ulcere stadio I  (qualsiasi causa) ---------------------------------\n");
        printw("1b.Ulcere stadio II (qualsiasi causa) ---------------------------------\n");
        printw("1c.Ulcere stadio III(qualsiasi causa) ---------------------------------\n");
        printw("1d.Ulcere stadio IV (qualsiasi causa) ---------------------------------\n");
        printw("2a.Stadio raggiunto dall'ulcera da decubito piu' grave-----------------\n");
        printw("4b.Ustioni-------------------------------------------------------------\n");
        printw("4c.Lesioni aperte esclusi rash o tagli (es. cancerose o lacerocontuse)-\n");
        printw("4g.Ferite chirurgiche -------------------------------------------------\n");
        printw("5a.Sedie o carrozzine attrezzate con dispositivo antidecubito----------\n");
        printw("5b.Letti attrezzati con dispositivo antidecubito-----------------------\n");
        printw("5c.Programmi di rotazione/ documentaz. di riposizionamento dell'ospite-\n");
        printw("5d.Terapie nutrizionali o reidratanti per gestire problemi cutanei-----\n");
        printw("5e.Interventi per la cura dell'ulcera (piede compreso)-----------------\n");
        printw("5f.Interventi per la cura della ferita chirurgica ---------------------\n");
        printw("5g.Medicazioni (piede escluso)-----------------------------------------\n");
        printw("5h.Applicazione di unguenti/farmaci (compresi oli e creme)-------------\n");
        printw("6b.Piede: infezioni (ad es. celluliti o drenaggi purulenti)------------\n");
        printw("6c.Piede: lesioni aperte (tagli,ulcere,fessure)------------------------\n");
        printw("6f.Piede: medicazioni con o senza applicazione di farmaci topici-------");











       for (j=0;j<4;j++)
        {
            move (3+j,73);

            printw ("%d",archivio.cute[j]);
        }






            move (7,73);


            printw ("%s",romani[archivio.cute[4]]);

        for (j=5;j<19;j++)
        {
            move (j+3,73);
            if (!(archivio.cute[j]))
                printw ("NO");
            else
                printw ("SI");
        }


    y=griglia(73,3,0,y,1,1,0,18).y;


    if (ch=='q')
        break;

    if (y>4)
    {
    do
    {
        move (3+y,73);
      d=getch();

      if ((d=='w')||(d=='s'))
            archivio.cute[y]=!(archivio.cute[y]);

            if (!(archivio.cute[y]))
                printw ("NO");
            else
                printw ("SI");
    } while (d!='\n');
    }

    if (y==4)
    {
    do
    {
    move (7,73);
    d=getch();
     if ((d=='w')&&(archivio.cute[y]<4))
                archivio.cute[y]++;
    if ((d=='s')&&(archivio.cute[y]>0))
                archivio.cute[y]--;
         printw ("%s",romani[archivio.cute[4]]);
    } while (d!='\n');

    }
    if (y<4)
    {
    do
    {
        move (3+y,73);

        d=getch();



            if ((d=='w')&&(archivio.cute[y]<20))
                archivio.cute[y]++;
            if ((d=='s')&&(archivio.cute[y]>0))
                archivio.cute[y]--;

            printw ("%d",archivio.cute[y]);


    } while (d!='\n');




    }

for (h=0;h<4;h++)
    {
    if (archivio.cute[h])
        max_stadio=h+1;
    }
    if (archivio.cute[4]>max_stadio)
        archivio.cute[4]=max_stadio;
}
}

void attivita (int i)

{
    char d;
    int j;
    int y=0;

    while (1)
    {
        clear ();
        printw ("#%d    Letto:%s %s %s\nSEZIONE N: ATTIVITA' negli ultimi 7 giorni.",i+1,letti[i],archivio.cognome,archivio.nome);
        printw (" Tempo in cui l'ospite è sveglio\nSI=sveglio per la maggior parte del tempo;\nNO=dorme o sonnecchia per più di un'ora:\n\n\n\n");



        printw("a. Mattino------------------------------------------------------------\n\n\n");
        printw("b. Pomeriggio---------------------------------------------------------\n\n\n");
        printw("a. Sera---------------------------------------------------------------\n\n\n");




       for (j=0;j<3;j++)
        {
            move (7+3*j,73);
            if (!(archivio.attivita[j]))
                printw ("NO");
            else
                printw ("SI");
        }



    y=griglia(73,7,0,y,2,3,0,2).y;


    if (ch=='q')
        break;

    do
    {
        move (7+3*y,73);
      d=getch();
      if ((d=='w')||(d=='s'))
            archivio.attivita[y]=!(archivio.attivita[y]);

            if (!(archivio.attivita)[y])
                printw ("NO");
            else
                printw ("SI");
    } while (d!='\n');


    }

}

void iniezioni(int i)

{
char d;


    clear ();
    printw ("#%d    Letto:%s %s %s\nSEZIONE O: FARMACI negli ultimi 7 giorni.",i+1,letti[i],archivio.cognome,archivio.nome);
    move (5,0);
    printw ("Numero di giorni della settimana in cui l'ospite ha ricevuto iniezioni\ndi qualunque tipo: ");

    while (1)
    {
        move (6,20);
         printw ("%d",archivio.iniezioni);
         move (6,20);
        d=getch();
        if ((d=='w')&&(archivio.iniezioni<7))
            archivio.iniezioni++;
        if ((d=='s')&&(archivio.iniezioni>0))
            archivio.iniezioni--;



        if (d=='q')
            break;

    }










}

void speciali (int i)

{
    char d;
    short j,k;
    struct coord a;
    a.x=a.y=0;
    short y=0;
    short pagina=1;

    while (1)
    {
        clear ();
        printw ("#%d    Letto:%s %s %s\nSEZIONE P TRATTAMENTI SPECIALI negli ultimi 14 giorni\n\n",i+1,letti[i],archivio.cognome,archivio.nome);
        printw ("PAGINA %d di 4 - premi 'p' per cambiare pagina\n_________________________________________________________________________",pagina);

        switch (pagina)
        {
            case 1:
            printw ("\nA)TRATTAMENTI SPECIALI:\ntrattamenti o programmi speciali ricevuti negli ultimi 14 giorni\n\n");

            printw("a. Chemioterapia oncologica-----------------\n");
            printw("b. Dialisi----------------------------------\n");
            printw("c. Infusione endovenosa---------------------\n");
            printw("g. Ossigenoterapia--------------------------\n");
            printw("h. Radioterapia-----------------------------\n");
            printw("i. Aspirazione------------------------------\n");
            printw("j. cura della tracheostomia-----------------\n");
            printw("k. Trasfusioni------------------------------\n");
            printw("l. Respiratore - Ventilazione assistita-----\n");

            for (j=0;j<9;j++)
            {
                move (8+j,45);
                if (!(archivio.trattamenti[j]))
                    printw ("NO");
                else
                    printw ("SI");
            }

            a.y=griglia (45,8,a.x,a.y,2,1,0,8).y;

            if ((ch=='p')||(ch=='q'))
                break;

            do
            {
                move (8+a.y,45);
                d=getch();
                if ((d=='w')||(d=='s'))
                    archivio.trattamenti[a.y]=!(archivio.trattamenti[a.y]);
                if (!(archivio.trattamenti[a.y]))
                    printw ("NO");

                else
                    printw ("SI");


            } while (d!='\n');


            break;

            case 2:
            printw ("\nB)TERAPIE SPECIALI NEGLI ULTIMI 7 GIORNI\n\tA= numero giorni di terapia per 15 min. o più ");
            printw ("\n\tB= numero minuti totali di terapia erogati negli ultimi 7 giorni");
            move (10,0);
            printw("Logoterapia------------------------------\n\n");
            printw("Terapia occupazionale--------------------\n\n");
            printw("Fisioterapia-(per recupero funzionale----\n\n");
            printw("Terapia respiratoria---------------------\n(anche aerosol eseguiti da infermiere)");
            move(9,45);
            addch('A');
            move(9,60);
            addch('B');
            for (j=0;j<4;j++)
            {
                for (k=0;k<2;k++)
                    mvprintw (10+2*j,45+15*k,"%d",archivio.terapie[j][k]);

            }

            a=griglia (45,10,a.x,a.y,15,2,1,3);


            if ((ch=='p')||(ch=='q'))
                break;



            do
            {
                move (10+2*a.y,45+15*a.x);
                d=getch();

                if ((d=='w')&&(archivio.terapie[a.y][a.x]<7+993*a.x))
                    archivio.terapie[a.y][a.x]++;
                if ((d=='s')&&(archivio.terapie[a.y][a.x]>0))
                    archivio.terapie[a.y][a.x]--;


                printw("%d  ",archivio.terapie[a.y][a.x]);
            } while (d!='\n');



            break;

             case 3:
             printw ("\nASSISTENZA RIABILITATIVA INTEGRATIVA - negli ultimi 7 giorni");
             printw ("\nnumero di giorni/settimana in cui è stata erogata\n\n");

             printw("a. Movimento passivo--------------------------------------\n");
             printw("b. Movimento attivo(gruppi di meno di 5 persone)----------\n");
             printw("c. Stecche o rinforzi-------------------------------------\n");
             printw("d. Mobilita' a letto (solo insegnamento)------------------\n");
             printw("e. Trasferimenti (solo insegnamento)----------------------\n");
             printw("f. Camminare (solo insegnamento)--------------------------\n");
             printw("g. Vestirsi o agghindarsi (solo insegnamento)-------------\n");
             printw("h. Mangiare o inghiottire (solo insegnamento)-------------\n");
             printw("i. Cura della protesi  per amputati (solo insegnamento)---\n");
             printw("j. Comunicare (solo insegnamento)-------------------------");

            for (j=0;j<10;j++)
            {
                move (8+j,60);
                printw ("%d",archivio.riabilitazione[j]);
            }

            a=griglia (60,8,a.x,a.y,2,1,0,9);

             if ((ch=='p')||(ch=='q'))
                break;




            do
            {
                move (8+a.y,60);
                d=getch();
                if ((d=='w')&&(archivio.riabilitazione[a.y]<7))
                    archivio.riabilitazione[a.y]++;
                if ((d=='s')&&(archivio.riabilitazione[a.y])>0)
                    archivio.riabilitazione[a.y]--;
                printw("%d",archivio.riabilitazione[a.y]);
            }   while (d!='\n');

            break;

            case 4:
            printw ("\nVISITE E PRESCRIZIONI MEDICHE\n");
            printw("Segnare quante volte l'ospite ha ricevuto visite o nuove prescrizioni\n");
            printw("negli ultimi 30 giorni, o, se ammesso da meno tempo, dall'ammissione in RSA");
            move (11,0);
            printw("Visite (max 14)------------------ %d\n\n\n",archivio.visite);
            printw("Prescrizioni (max 14)------------ %d",archivio.prescrizioni);

            y=griglia(34,11,0,y,2,3,0,1).y;

            if ((ch=='p')||(ch=='q'))
                break;
            if (y==0)
            {
                do
                    {
                    move (11,34);
                    d=getch();
                    if((d=='w')&&(archivio.visite<14))
                        archivio.visite++;
                    if((d=='s')&&(archivio.visite>0))
                        archivio.visite--;
                    printw ("%d ",archivio.visite);
                    } while (d!='\n');
                    break;
            }


            else
            {
                do
                {
                    move (14,34);
                    d=getch();
                    if((d=='w')&&(archivio.prescrizioni<14))
                        archivio.prescrizioni++;
                    if((d=='s')&&(archivio.prescrizioni>0))
                        archivio.prescrizioni--;
                    printw ("%d ",archivio.prescrizioni);
                    } while (d!='\n');
                    break;
            }











        }



        if (ch=='q')
        break;
        if (ch=='p')
        {
        pagina++;
        if (pagina==5)
            pagina=1;
        }



    }

}

void diagnosi2 (int i)

{
    char d;
    int j;
    int y=0;

    while (1)
    {
        clear ();
        printw ("#%d    Letto:%s %s %s\nSEZIONE I: DIAGNOSI DI MALATTIA negli ultimi 14 giorni\n",i+1,letti[i],archivio.cognome,archivio.nome);
        printw ("Malattie psichiatriche/disturbi dell'umore negli ultimi 15 giorni\nInfezioni in corso");


        move (5,0);
        printw ("1dd. Ansia------------------------------------\n");
        printw ("1ee. Depressione------------------------------\n");
        printw ("1ff. Malattia bipolare-(maniaco-depressiva)---\n");
        printw ("1gg. Schizofrenia-----------------------------\n");
        printw ("2a.  Infezione antibioticoresistente----------\n");
        printw ("2b.  Clostridium difficile--------------------\n");
        printw ("2c.  Congiuntivite----------------------------\n");
        printw ("2d.  Infezione da HIV-------------------------\n");
        printw ("2e.  Polmonite--------------------------------\n");
        printw ("2f.  Infezione respiratoria-------------------\n");
        printw ("2g.  Setticemia-------------------------------\n");
        printw ("2h.  Malattie sessualmente trasmissibili------\n");
        printw ("2i.  Tubercolosi------------------------------\n");
        printw ("2j.  Infezioni urinarie (ultimi 30 gg)--------\n");
        printw ("2k.  Epatite virale---------------------------\n");
        printw ("2l.  Ferite infette---------------------------\n");





       for (j=0;j<16;j++)
        {
            move (5+j,47);
            if (!(archivio.diagnosi2[j]))
                printw ("NO");
            else
                printw ("SI");
        }


    y=griglia(47,5,0,y,2,1,0,15).y;


    if (ch=='q')
        break;

    do
    {
        move (5+y,47);
      d=getch();
      if ((d=='w')||(d=='s'))
            archivio.diagnosi2[y]=!(archivio.diagnosi2[y]);

            if (!(archivio.diagnosi2)[y])
                printw ("NO");
            else
                printw ("SI");
    } while (d!='\n');


    }

}

void incidenti (int i)

{
    char d;
    int j;
    int y=0;

    while (1)
    {
        clear ();
        printw ("#%d    Letto:%s %s %s\nSEZIONE J: INCIDENTI occorsi alla persona\n",i+1,letti[i],archivio.cognome,archivio.nome);

        move (9,0);

        printw ("a. Caduto negli ultimi 30 giorni---------------------------\n\n");
        printw ("b. Caduto negli ultimi 31-180 giorni-----------------------\n\n");
        printw ("c. Frattura di femore negli ultimi 180 giorni--------------\n\n");
        printw ("d. Altra frattura negli ultimi 180 giorni------------------");


       for (j=0;j<4;j++)
        {
            move (9+2*j,70);
            if (!(archivio.incidenti[j]))
                printw ("NO");
            else
                printw ("SI");
        }


    y=griglia(70,9,0,y,2,2,0,3).y;


    if (ch=='q')
        break;

    do
    {
        move (9+2*y,70);
      d=getch();
      if ((d=='w')||(d=='s'))
            archivio.incidenti[y]=!(archivio.incidenti[y]);

            if (!(archivio.incidenti)[y])
                printw ("NO");
            else
                printw ("SI");
    } while (d!='\n');


    }

}

void guarigioni (int i)
{
char d;
clear ();
printw ("#%d    Letto:%s %s %s\nSEZIONE M2: CONDIZIONI DELLA CUTE\n",i+1,letti[i],archivio.cognome,archivio.nome);
printw ("Storia di ulcere guarite negli ultimi 90 giorni");
move (9,0);
printw ("L'ospite ha avuto un'ulcera che è stata curata o si è risolta\n");
printw ("negli ultimi 90 giorni?  ");

if (!(archivio.guarigioni))
    printw ("NO");
else
    printw ("SI");

do
    {
        move (10,25);
        d=getch();
        if ((d=='w')||(d=='s'))
            archivio.guarigioni=!(archivio.guarigioni);
        if (!(archivio.guarigioni))
            printw("NO");
        else
            printw("SI");

    } while ((d!='\n')&&(d!='q'));

}

void speciali2 (int i)

{
    char d;
    short j;
    struct coord a;
    a.x=a.y=0;
    short pagina=1;

    while (1)
    {
        clear ();
        printw ("#%d    Letto:%s %s %s\nSEZIONE P TRATTAMENTI SPECIALI/2\n\n",i+1,letti[i],archivio.cognome,archivio.nome);
        printw ("PAGINA %d di 4 - premi 'p' per cambiare pagina\n_________________________________________________________________________",pagina);

        switch (pagina)
        {
            case 1:
            printw ("\n4)STRUMENTI E MEZZI DI CONTENZIONE\nCodifica: 0=non usato - 1=usato non quotidianamente - 2=usato quotidianamente\n\n");

            printw("a. Spondine su tutti i lati aperti del letto--\n\n");
            printw("b. Altri tipi di spondine---------------------\n\n");
            printw("c. Mezzi di contenzione al tronco-------------\n\n");
            printw("d. Mezzi di contenzione agli arti-------------\n\n");
            printw("h. Sedie contenitive (impedimento ad alzarsi)-\n\n");


            for (j=0;j<5;j++)
            {
                move (8+j*2,47);
                printw ("%d",archivio.contenzione[j]);
            }

            a.y=griglia (47,8,a.x,a.y,2,2,0,4).y;

            if ((ch=='p')||(ch=='q'))
                break;

            do
            {
                move (8+a.y*2,47);
                d=getch();
                if ((d=='w')&&(archivio.contenzione[a.y]<3))
                    archivio.contenzione[a.y]++;
                if ((d=='s')&&(archivio.contenzione[a.y]>0))
                    archivio.contenzione[a.y]--;
                printw("%d",archivio.contenzione[a.y]);


            } while ((d!='\n'));




            break;

            case 2:
            printw ("\n5)DEGENZE OSPEDALIERE negli ultimi 90 giorni");
            printw ("\nQuante volte, negli ultimi 90 giorni, l'ospite è stato ricoverato in ospedale per almeno una notte\n0= nessun ricovero");
            move (10,0);
            printw("Numero ricoveri :");

            printw("%d",archivio.degenze);

            do
            {
            move (10,17);
            ch=getch();
            if((ch=='w')&&(archivio.degenze<40))
                archivio.degenze++;
            if((ch=='s')&&(archivio.degenze>0))
                archivio.degenze--;
            printw ("%d ",archivio.degenze);

            } while ((ch!='q')&&(ch!='p'));




            break;

             case 3:
            printw ("\n6)VISITE IN PRONTO SOCCORSO negli ultimi 90 giorni");
            printw ("\nQuante volte, negli ultimi 90 giorni, l'ospite è stato in pronto soccorso senza essere ricoverato\n0= nessun accesso");
            move (10,0);
            printw("Numero accessi :");

            printw("%d",archivio.dea);

            do
            {
            move (10,16);
            ch=getch();
            if((ch=='w')&&(archivio.dea<40))
                archivio.dea++;
            if((ch=='s')&&(archivio.dea>0))
                archivio.dea--;
            printw ("%d ",archivio.dea);

            } while ((ch!='q')&&(ch!='p'));




            break;

             case 4:
            printw ("\n9)ESAMI DI LABORATORIO ANORMALI negli ultimi 90 giorni");
            printw ("\nL'ospite ha presentato valori di laboratorio anomali\n0= nessuna anomalia; 1= almeno un'anomalia");
            move(10,0);
            printw("Anomalie :");

            move (10,15);

            if (!(archivio.esami))
                printw("NO");
            else
                printw("SI");
            do
            {
            move (10,15);
            ch=getch();
            if((ch=='w')||(ch=='q'))
                archivio.esami=!(archivio.esami);

            if (!(archivio.esami))
                printw("NO");
            else
                printw("SI");


            } while ((ch!='q')&&(ch!='p'));




            break;














        }



        if (ch=='q')
        break;
        if (ch=='p')
        {
        pagina++;
        if (pagina==5)
            pagina=1;
        }



    }

}


void calcolarug (int i)

{

    clear ();
    short adl;
    short estensivo=0;
    short adl_bed,adl_transfer,adl_toilet,adl_eating;



    printw ("#%d    Letto:%s %s %s\nATTRIBUZIONE FASCIA RUG-III\n\n",i+1,letti[i],archivio.cognome,archivio.nome);

    if ((archivio.adl[0][0]==0)||(archivio.adl[0][0]==1))
            adl_bed=1;
    if ((archivio.adl[0][0]==2))
        adl_bed=3;
    if ((archivio.adl[0][0]>2))
    {
        if ((archivio.adl[0][1])<3)
        adl_bed=4;
        else
        adl_bed=5;
    }
    printw ("Punteggio ADL (mobilità a letto)\t=%d",adl_bed);

    if ((archivio.adl[1][0]==0)||(archivio.adl[1][0]==1))
            adl_transfer=1;
    if ((archivio.adl[1][0]==2))
        adl_transfer=3;
    if ((archivio.adl[1][0]>2))
    {
        if ((archivio.adl[1][1])<3)
        adl_transfer=4;
        else
        adl_transfer=5;
    }
    printw ("\nPunteggio ADL (trasferimenti)\t\t=%d",adl_transfer);

    if ((archivio.adl[3][0]==0)||(archivio.adl[3][0]==1))
            adl_toilet=1;
    if ((archivio.adl[3][0]==2))
        adl_toilet=3;
    if ((archivio.adl[3][0]>2))
    {
        if ((archivio.adl[3][1])<3)
        adl_toilet=4;
        else
        adl_toilet=5;
    }
    printw ("\nPunteggio ADL (eliminazione)\t\t=%d",adl_toilet);


    if ((archivio.nutrizione[1]==1) || ((archivio.nutrizione[2]==1)&&(archivio.nutrizione[3]>2)) || ((archivio.nutrizione[2]==1)&&(archivio.nutrizione[3]==2)&&(archivio.nutrizione[4]>1)))

        adl_eating=3;
    else
    {
        if (archivio.adl[2][0]<2)
            adl_eating=1;
        if (archivio.adl[2][0]==2)
            adl_eating=2;
        if (archivio.adl[2][0]>2)
            adl_eating=3;

    }
    printw ("\nPunteggio ADL (alimentazione)\t\t=%d",adl_eating);
    adl=adl_bed+adl_transfer+adl_toilet+adl_eating;
    printw("\n-----------------------------------------------\n");
    printw ("Punteggio totale ADL RUG-III\t\t=%d",adl);

    getch();


    /** CURE INTENSIVE **/


    clear();


    archivio.rug [0]=categ1(adl);

    if (categ1(adl))
    {
        if (adl>6)
        {
        printw ("CATEGORIA I:  CURE INTENSIVE");

            estensivo=archivio.nutrizione[1]+archivio.trattamenti[2];
            printw ("\nConto estensivo (parziale):%d\n",estensivo);
            if (special_care(adl))
            estensivo++;
            if (clinic_complex(adl))
            estensivo++;
            if (impaired_cogn(adl))
            estensivo++;
            printw ("conto estensivo totale:%d\n\nClassificazione RUG-III = ",estensivo);
            if (estensivo>3)
            {
                archivio.rug[1]=3;
                printw ("SE%d",archivio.rug[1]);
                getch();
                return;
            }
            if (estensivo>1)
            {
                archivio.rug[1]=2;
                printw ("SE%d",archivio.rug[1]);
                getch();
                return;
            }

            archivio.rug[1]=1;
            printw("SE%d",archivio.rug[1]);
            getch();
            return;
        }
            else
            {
            printw ("\nSebbene abbia i requisiti generali, non è qualificato per cure intensive perché ADL=%d\n",adl);

            if (riab())
                {
                printw ("CATEGORIA II  : RIABILITAZIONE\nCLASSIFICAZIONE RUG-II = RAA");
                archivio.rug[0]=2;
                archivio.rug[1]=1;

                getch ();
                return;
                }
                else
                {
                printw ("CATEGORIA III  : CURE SPECIALI\nCLASSIFICAZIONE RUG-II = SSA");
                archivio.rug[1]=1;
                archivio.rug[0]=3;

                getch();
                return;
                }


            }
        }









    else
        printw ("Non qualificato per categoria I (assistenza intensiva)\n");

    /**RIABILITAZIONE**/


    archivio.rug [0] = 2*riab();


    if (archivio.rug[0]==2)
    {
        printw ("CATEGORIA II:    RIABILITAZIONE\n");
        if (adl<10)
            {
                archivio.rug[1]=1;
                printw ("Classificazione RUG-III: RAA\n");
            }
        if ((adl>9)&&(adl<14))
            {
                archivio.rug[1]=2;
                printw ("Classificazione RUG-III: RAB\n");
            }
        if ((adl>13)&&(adl<17))
            {
                archivio.rug[1]=3;
                printw ("Classificazione RUG-III: RAC\n");
            }
        if (adl>16)
            {
                archivio.rug[1]=4;
                printw ("Classificazione RUG-III: RAD\n");
            }
        getch();
        return;
    }

    printw("Non qualificato per categoria II (riabilitazione)\n");

    /** CURE SPECIALISTICHE **/

    if (special_care(adl))
    {
        printw ("CATEGORIA III :  CURE SPECIALISTICHE\n\nClassificazione RUG-III= SS");
        archivio.rug[0]=3;
        if (adl>16)
        {
            archivio.rug[1]=3;
            addch('C');
            getch();
            return;
        }
        if (adl>15)
        {
            archivio.rug[1]=2;
            addch('B');
            getch();
            return;
        }
        if (adl>6)
        {
            archivio.rug[1]=1;
            addch('A');
            getch();
            return;
        }

    }

    printw ("\nNon qualificato per categoria III (cure specialistiche)\n");

    /** CLINICAMENTE COMPLESSO **/

    if (clinic_complex(adl))
    {
    printw ("\nCATEGORIA IV : CLINICAMENTE COMPLESSO\n\nCLASSIFICAZIONE RUG-III= C");
    archivio.rug[0]=4;
    short depress=0;
    short h;
    bool depr_index=FALSE;

    for (h=0;h<16;h++)
    {
        if (archivio.umore[h])
            depress++;
    }

    if (depress>2)
        depr_index=TRUE;
    else
        depr_index=FALSE;

    if (depr_index)
    {
     if (adl>16)
     {
        archivio.rug[1]=6;
        printw("C2");
        getch();
        return;
     }
     if (adl>11)
     {
        archivio.rug[1]=4;
        printw("B2");
        getch();
        return;
     }

     archivio.rug[1]=2;
     printw("A2");
     getch();
     return;

    }
    else
    {
    if (adl>16)
     {
        archivio.rug[1]=5;
        printw("C1");
        getch();
        return;
     }
     if (adl>11)
     {
        archivio.rug[1]=3;
        printw("B1");
        getch();
        return;
     }

     archivio.rug[1]=1;
     printw("A1");
     getch();
     return;


    }

    }

    /**DEFICIT COGNITIVO**/

    printw ("\nNon qualificato per categoria IV (clinicamente complesso)\n");

    short nrs;
    nrs=nursing_rehab();

    if (impaired_cogn(adl))

    {
        if (adl<11)
        {
        printw ("\nCATEGORIA V : DEFICIT COGNITIVO\n\nCLASSIFICAZIONE RUG-III = I");
        archivio.rug[0]=5;
        if (adl<6)
        {
            if (nrs<2)
            {
                archivio.rug[1]=1;
                printw("A1");
                getch();
                return;
            }
            else
            {
                archivio.rug[1]=2;
                printw("A2");
                getch();
                return;
            }

        }
        else
        {
         if (nrs<2)
            {
                archivio.rug[1]=3;
                printw("B1");
                getch();
                return;
            }
            else
            {
                archivio.rug[1]=4;
                printw("B2");
                getch();
                return;
            }





        }


        }
        else
            printw ("\nNon qualificato per categoria V (deficit cognitivo); ADL troppo alto\n");

    }
    else
        printw ("\nNon qualificato per categoria V (deficit cognitivo)\n");

/** PROBLEMI COMPORTAMENTALI **/

if ((adl<11)&&(behavior()))
{
    printw ("\nCATEGORIA VI : PROBLEMI COMPORTAMENTALI\n");
    printw ("CLASSIFICAZIONE RUG-III = B");
    archivio.rug[0]=6;
     if (adl<6)
        {
            if (nrs<2)
            {
                archivio.rug[1]=1;
                printw("A1");
                getch();
                return;
            }
            else
            {
                archivio.rug[1]=2;
                printw("A2");
                getch();
                return;
            }

        }
        else
        {
         if (nrs<2)
            {
                archivio.rug[1]=3;
                printw("B1");
                getch();
                return;
            }
            else
            {
                archivio.rug[1]=4;
                printw("B2");
                getch();
                return;
            }
        }

}

    printw ("\nNon qualificato per categoria VI (problemi comportamentali)\n");
    printw ("\nCATEGORIA VII : FUNZIONI FISICHE RIDOTTE\n");
    printw ("CLASSIFICAZIONE RUG-III = P");
    archivio.rug[0]=7;

    if (adl<6)
        {
            if (nrs<2)
            {
                archivio.rug[1]=1;
                printw("A1");
                getch();
                return;
            }
            else
            {
                archivio.rug[1]=2;
                printw("A2");
                getch();
                return;
            }

        }
    if ((adl>5)&&(adl<9))
        {
         if (nrs<2)
            {
                archivio.rug[1]=3;
                printw("B1");
                getch();
                return;
            }
            else
            {
                archivio.rug[1]=4;
                printw("B2");
                getch();
                return;
            }
        }
    if ((adl>8)&&(adl<11))
        {
         if (nrs<2)
            {
                archivio.rug[1]=5;
                printw("C1");
                getch();
                return;
            }
            else
            {
                archivio.rug[1]=6;
                printw("C2");
                getch();
                return;
            }
        }
    if ((adl>10)&&(adl<16))
        {
         if (nrs<2)
            {
                archivio.rug[1]=7;
                printw("D1");
                getch();
                return;
            }
            else
            {
                archivio.rug[1]=8;
                printw("D2");
                getch();
                return;
            }
        }
        if (adl>15)
        {
         if (nrs<2)
            {
                archivio.rug[1]=9;
                printw("E1");
                getch();
                return;
            }
            else
            {
                archivio.rug[1]=10;
                printw("E2");
                getch();
                return;
            }
        }






    getch();
    return;

    }






































bool categ1(int adl)

{
if ((archivio.nutrizione[1])||(archivio.trattamenti[2])||(archivio.trattamenti[5])||(archivio.trattamenti[6])||(archivio.trattamenti[8]))


    return (TRUE);

    else

    return (FALSE);


}

bool riab (void)
{

    short j,riabm,riabg;
    riabm=riabg=0;
    short nrs;




    for (j=0;j<3;j++)
    {
        riabm=riabm+archivio.terapie[j][1];
        riabg=riabg+archivio.terapie[j][0];
    }

    nrs=nursing_rehab ();

    printw ("\nTotale minuti/sett. riabilitazione speciale =%d",riabm);
    printw ("\nTotale giorni/sett. riabilitazione speciali =%d",riabg);
    printw ("\nTotale nursing rehab =%d\n",nrs);




    if (riabm<45)
    {
        printw("\nTroppo pochi minuti di terapia qualificata\n");
        return (FALSE);
    }
    if ((nrs>1)&&(riabg>2))
    {
        printw ("\nrequisiti ok\n");
        return (TRUE);
    }
    if ((riabm>150)&&(riabg>4))
    {
    printw ("\nrequisiti ok\n");
        return (TRUE);

    }



    return(FALSE);
}

bool special_care(int adl)

{
    short k;
    short conto=0;

    if ((archivio.diagnosi1[2])&&(adl>9))
        conto++;
    if ((archivio.diagnosi1[4])&&(adl>9))
        conto++;
    if ((archivio.diagnosi1[5])&&(adl>9))
        conto++;
    if (archivio.problemi[2]) //FEBBRE
    {
        if (archivio.diagnosi2[8]) //polmonite
            conto++;
        if (archivio.problemi[0]) //disidratazione
            conto++;
        if (archivio.problemi[5]) //vomito
            conto++;
        if (archivio.nutrizione[0]) //perdita di peso
             conto++;
        if (archivio.nutrizione[2]) //feeding tube conditions
         {
            if ((archivio.nutrizione[3]>2)||((archivio.nutrizione[3]==2)&&(archivio.nutrizione[4]>1)))
                conto++;

         }
    }

    if (archivio.diagnosi1[1]) //afasia
    {
        if (archivio.nutrizione[2]) //feeding tube conditions
        {
            if ((archivio.nutrizione[3]>2)||((archivio.nutrizione[3]==2)&&(archivio.nutrizione[4]>1)))
            printw("afasia+feeding tube\n");
                conto++;

        }
    }

    if ((archivio.cute[0]+archivio.cute[1]+archivio.cute[2]+archivio.cute[3])>1)
    {
        if (skin_treatments()>1)
        {
            printw ("2 o più ulcere cutanee con trattamenti cutanei\n");
            conto++;
        }
    }

    if (archivio.cute[4]>2) //LESIONI III STADIO
    {
        if (skin_treatments()>1)
            conto++;
    }

    if (archivio.cute[6]) //LESIONI APERTE
    {
        for (k=0;k<3;k++)
        {
        if (archivio.cute[13+k])
            conto++;

        }


    }

    if (archivio.cute[7]) //FERITE CHIRURGICHE
    {
        for (k=0;k<3;k++)
        {
        if (archivio.cute[13+k])
            conto++;
        }

    }

    if (archivio.trattamenti[4])
        conto++;

    if (archivio.terapie[3][0]>6)
        conto++;






if (conto)
    {
        return (TRUE);
    }
else
    {
        return (FALSE);
    }

}

short (skin_treatments())
{
int j;
short tratt=0;

if ((archivio.cute[8])||(archivio.cute[9]))
    tratt++;
for (j=0;j<5;j++)
{
    if ((archivio.cute[10+j])&&(j!=3))
        tratt++;
}



return (tratt);
}

bool clinic_complex(int adl)
{
short conto=0;

short h;
short dipend=0;

if ((archivio.cognitivo[0]==1)&&!(archivio.attivita[0])&&!(archivio.attivita[1])&&!(archivio.attivita[2]))
{
    for (h=0;h<4;h++)
    {
    dipend=dipend+archivio.adl[h][0];
    }
    if ((dipend>15)&&(archivio.cognitivo[2]==4))
    {
        printw("\nComa, non vigile, totalmente dipendente\n");
        conto++;
    }
}




if (archivio.diagnosi2[8]) //polmonite
    conto++;
if (archivio.diagnosi2[10]) //setticemia
    conto++;
if ((archivio.diagnosi1[0])&&(archivio.iniezioni=7)&&(archivio.prescrizioni>1)) //diabete non stabilizzato
{
    printw ("Soddisfa la condizione: diabete insulinodipendente non stabilizzato\n");
    conto++;
}
if (archivio.diagnosi1[3]) //emiplegia con dipendenza forte nelle ADL
{
    if (adl>10)
    {
    printw ("Soddisfa la condizione: emiplegia/emiparesi con dipendenza forte nelle ADL\n");
    conto++;
    }
}

if (archivio.problemi[0]) //disidratazione
    conto++;

if (archivio.problemi[4]) //emorragie
    conto++;

if (archivio.nutrizione[2]) //feeding tube conditions
        {
            if ((archivio.nutrizione[3]>2)||((archivio.nutrizione[3]==2)&&(archivio.nutrizione[4]>1)))
            printw("Soddisfa la condizione: nutrizione enterale totale\n");
                conto++;

        }
if ((archivio.cute[16])&&(archivio.cute[18]))
{
    printw ("Infezione del piede con medicazioni\n");
    conto++;
}

if ((archivio.cute[17])&&(archivio.cute[18]))
{
    printw ("Ulcera del piede diabetico/lesioni al piede aperte con medicazioni\n");
    conto++;
}


if (archivio.cute[5])
{
    printw ("Ustioni\n");
    conto++;
}

if (archivio.trattamenti[0])
{
    printw ("Chemioterapia\n");
    conto++;
}

if (archivio.trattamenti[3])
{
    printw ("Ossigenoterapia\n");
    conto++;
}

if (archivio.trattamenti[7])
{
    printw ("Trasfusioni\n");
    conto++;
}

if (archivio.trattamenti[1])
{
    printw ("Dialisi\n");
    conto++;
}

if (((archivio.visite)&&(archivio.prescrizioni>3))||((archivio.visite>1)&&(archivio.prescrizioni>1)))
{
    printw ("Ripetute visite e prescrizioni\n");
    conto++;
}



if (conto)
return (TRUE);
else
return (FALSE);
}

bool impaired_cogn(int adl)
{
short conto=0;
short h;
short dipend=0;

if ((archivio.cognitivo[0]==1)&&!(archivio.attivita[0])&&!(archivio.attivita[1])&&!(archivio.attivita[2]))
{
    for (h=0;h<4;h++)
    {
    dipend=dipend+archivio.adl[h][0];
    }
    if ((dipend>15)&&(archivio.cognitivo[2]==4))
    {
        printw("\nComa, non vigile, totalmente dipendente\n");
        conto++;
    }
}

    if (archivio.cognitivo[2]==3)
    {
        printw ("\nCapacità di prendere decisioni compromessa\n");
        conto++;
    }

    short impair1;
    short impair2;

    if ((archivio.cognitivo[1]!=2)||(archivio.cognitivo[2]!=4)||(archivio.comprensione!=4))
    {
       impair1=(archivio.cognitivo[1]==1)+(archivio.cognitivo[2]>0)+(archivio.comprensione>0);
       impair2=(archivio.cognitivo[2]>1)+(archivio.comprensione>1);

       printw ("\nimpair1=%d-impair2=%d",impair1,impair2);

       if ((impair1>1)&&(impair2))
       {
       printw ("\nImpaired cognition condition verified\n");
        conto++;
        }
    }







if (conto)
return (TRUE);

else

return (FALSE);
}

bool behavior (void)

{
    short conto=0;

    if (archivio.comportamento[0][0]>1)
    {
        printw ("itinerante-");
        conto++;
    }
    if (archivio.comportamento[1][0]>1)
    {
        printw ("offensivo-");
        conto++;
    }
    if (archivio.comportamento[2][0]>1)
    {
        printw ("fisicamente violento-");
        conto++;
    }
    if (archivio.comportamento[3][0>1])
    {
        printw (" comportamento inadeguato -");
    }
    if (archivio.comportamento[4][0]>1)
    {
        printw (" rifiuta l'assistenza -");
        conto++;
    }
    if (archivio.comportamento[1][0]>1)
    {
        printw ("offensivo-");
        conto++;
    }
    if (archivio.problemi [3])
    {
        printw ("- allucinazioni -");
        conto++;
    }
    if (archivio.problemi [2])
    {
        printw ("- episodi psicotici -");
        conto++;
    }



    if (conto)
        return (TRUE);
    else
        return (FALSE);
}


short nursing_rehab (void)

{
short nrs;
short j;

nrs=(archivio.continenza[0]>5)||(archivio.continenza[1]>5);

   if ((archivio.riabilitazione[0]>5)||(archivio.riabilitazione[1]>5))
    nrs++;

    if (archivio.riabilitazione[2]>5)
    nrs++;

   if ((archivio.riabilitazione[3]>5)||(archivio.riabilitazione[5]>5))
    nrs++;

    if (archivio.riabilitazione[4]>5)
    nrs++;

    for (j=6;j<10;j++)
    {
        if (archivio.riabilitazione[j]>5)
            nrs++;
    }

    return (nrs);


}

struct coord griglia (int xo,int yo,int xpart, int ypart, int xsize,int ysize,int xmax,int ymax)


{

struct coord posiz;

int x,y,oldx,oldy;
x=xpart;
y=ypart;


do
{

	mvprintw (yo+ysize*y,xo+xsize*x-1,">");

	ch=getch();
	if ((ch=='q')||(ch=='p'))
        break;
	oldx=x;oldy=y;

	if ((ch=='s')&&(y<ymax))
		y++;
	if ((ch=='w')&&(y>0))
		y--;

	if ((ch=='d')&&(x<xmax))
		x++;
	if ((ch=='a')&&(x>0))
		x--;

     mvprintw (yo+ysize*oldy,xo+xsize*oldx-1," ");


} while (ch!='\n');

move (yo+ysize*y,xo+xsize*x);



posiz.x=x;
posiz.y=y;








    refresh();
	return (posiz);

}

void save_text(int i)

{
    clear();
    show_paz (i);



    if (archivio.rug[0]==0)
    {
    printw ("\nClassificazione RUG non eseguita! Sei sicuro di voler stampare la scheda?");
    char c=0;

    while ((c!='s')&&(c!='n'))
        c=getch();
    if (c=='n')
        return;
    }

    printw ("\nSalvataggio scheda sotto forma di testo: premi un tasto");
    getch();


    char destination [30];
    int k;
    short l;


    strcpy (destination,"text/");

    l=strlen(archivio.cognome);

    for (k=0;k<l;k++)
        destination [k+5]=archivio.cognome[k];
    destination [l+5]='.';
    destination [l+6]='t';
    destination [l+7]='x';
    destination [l+8]='t';
    destination [l+9]=0;
    h=fopen (destination,"w");
    fprintf (h,"RESIDENZA BOCCADASSE - SCHEDA RUG-III VERSIONE 5.2 (34 GRUPPI)\n\n");
    fprintf (h,"AA. ANAGRAFICA\n");
    fprintf (h,"---------------------------------------------------------------------------------------\n");
    fprintf (h,"Cognome: %s\t\tNome: %s\t\tLetto: %s\n",archivio.cognome,archivio.nome,letti[i]);
    fprintf (h,"Data di nascita    : %2d/%2d/%4d\n",archivio.nascita.giorno,archivio.nascita.mese,archivio.nascita.anno);
    fprintf (h,"Data di ingresso   : %2d/%2d/%4d\n",archivio.ingresso.giorno,archivio.ingresso.mese,archivio.ingresso.anno);
    fprintf (h,"Data di valutazione: %2d/%2d/%4d\n\n",archivio.valutazione.giorno,archivio.valutazione.mese,archivio.valutazione.anno);

     if (!(archivio.tempor))
        fprintf (h,"Inserimento definitivo\n\n");
    else
        fprintf (h,"Inserimento temporaneo\n\n");

    fprintf (h,"Codice Fiscale : %s\n\n",archivio.codice_fiscale);
    fprintf (h,"Annotazioni:\n%s\n\n",archivio.annotazioni);
    fprintf (h,"Diagnosi d'ingresso:\n%s\n\n\n",archivio.malattie);

    fprintf (h,"B.  STATO COGNITIVO\n");
    fprintf (h,"---------------------------------------------------------------------------------------\n");
    fprintf (h,"1.  Stato di coma:\t\t");
    if (archivio.cognitivo [0]==1)
        fprintf (h,"SI\n\n");
    else
        fprintf (h,"NO\n\n");
        fprintf (h,"2.  Memoria a breve termine (dopo 5 minuti):\t");
        if (!(archivio.cognitivo[1]))
            fprintf (h,"OK");
        else
        {
        if (archivio.cognitivo[1]==1)
            fprintf (h,"Problemi di memoria");
        else
            fprintf (h,"Non determinabile");

        }
    fprintf (h,"\n\n4.  Capacita' di prendere decisioni:\t\t");

    fprintf (h,"%s",decisioni[archivio.cognitivo[2]]);


    fprintf (h,"\n\n\nC.  COMUNICAZIONE\n");
    fprintf (h,"---------------------------------------------------------------------------------------\n");
    fprintf (h,"4.  Capacità di esprimere il contenuto delle informazioni (ultimi 7 giorni):\n");
    fprintf (h,"%s\n",comun[archivio.comprensione]);

    fprintf (h,"\n\n\nE1. UMORE negli ultimi 15 giorni\n");
    fprintf (h,"(0 non mostrato, 1 fino a cinque giorni/sett. 2 giornalmente)\n");
    fprintf (h,"---------------------------------------------------------------------------------------\n");
    fprintf (h,"a.affermazioni negative-----------------------------------------------------%d\n",archivio.umore[0]);
    fprintf (h,"b.domande ripetitive--------------------------------------------------------%d\n",archivio.umore[1]);
    fprintf (h,"c.ripetute richieste di aiuto-----------------------------------------------%d\n",archivio.umore[2]);
    fprintf (h,"d.rabbia o irritabilità-----------------------------------------------------%d\n",archivio.umore[3]);
    fprintf (h,"e.autodisistima-------------------------------------------------------------%d\n",archivio.umore[4]);
    fprintf (h,"f.espressione di paure non reali--------------------------------------------%d\n",archivio.umore[5]);
    fprintf (h,"g.l'ospite afferma in modo ricorrente l'imminenza di un evento terribile----%d\n",archivio.umore[6]);
    fprintf (h,"h.ripetute lamentele rispetto alla propria salute---------------------------%d\n",archivio.umore[7]);
    fprintf (h,"i.manifestazioni ripetute di ansia------------------------------------------%d\n",archivio.umore[8]);
    fprintf (h,"PROBLEMI CON IL SONNO\n");
    fprintf (h,"j.cattivo umore la mattina--------------------------------------------------%d\n",archivio.umore[9]);
    fprintf (h,"k.insonnia - cambiamenti del normale ciclo del sonno------------------------%d\n",archivio.umore[10]);
    fprintf (h,"ATTEGGIAMENTO TRISTE, APATICO, ANSIOSO\n");
    fprintf (h,"l.espressione del volto triste, addolorata, preoccupata---------------------%d\n",archivio.umore[11]);
    fprintf (h,"m.pianto, facilità alle lacrime---------------------------------------------%d\n",archivio.umore[12]);
    fprintf (h,"n.movimenti ripetitivi------------------------------------------------------%d\n",archivio.umore[13]);
    fprintf (h,"PERDITA D'INTERESSE\n");
    fprintf (h,"o.astensione da attività interessanti---------------------------------------%d\n",archivio.umore[14]);
    fprintf (h,"p.ridotte interazioni sociali-----------------------------------------------%d\n",archivio.umore[15]);

    fprintf (h,"\n\n\nE2. COMPORTAMENTO negli ultimi 7 giorni\n");
    fprintf (h,"A Frequenza dei problemi\n(0 non mostrato, 1= da 1 a 3 gg./sett. 2= da 4 a 6 gg/sett., 3= quotidiana)\n");
    fprintf (h,"B Possibilità di modificare i problemi negli ultimi 7 giorni\n(0 problema assente o modificabile, 1 problema difficilmente modificabile)\n");
    fprintf (h,"---------------------------------------------------------------------------------------\n");
    fprintf (h,"                                                        A               B\n");
    fprintf (h,"a.Vagare senza motivo, incurante della sicurezza        %d               %d\n",archivio.comportamento[0][0],archivio.comportamento[0][1]);
    fprintf (h,"b.Usare linguaggio offensivo                            %d               %d\n",archivio.comportamento[1][0],archivio.comportamento[1][1]);
    fprintf (h,"c.Essere fisicamente aggressivo                         %d               %d\n",archivio.comportamento[2][0],archivio.comportamento[2][1]);
    fprintf (h,"d.Comportamento socialmente inadeguato                  %d               %d\n",archivio.comportamento[3][0],archivio.comportamento[3][1]);
    fprintf (h,"e.Rifiutare l'assistenza                                %d               %d\n",archivio.comportamento[4][0],archivio.comportamento[4][1]);


    fprintf (h,"\n\n\nG:  FUNZIONE FISICA E PROBLEMI RELATIVI ALLA STRUTTURA\n");
    fprintf (h,"Negli ultimi 7 giorni / 7 notti\n");
    fprintf (h,"A Autonomia nelle ADL: 0 indipendente, 1 supervisione, 2 assistenza limitata,\n3 assistenza intensiva,");
    fprintf (h," 4 dipendenza totale, 8 attività mai eseguita\n");
    fprintf (h,"B Aiuto fornito nelle ADL: 0 nessuno, 1 solo organizzazione, 2 aiuto fisico (1 persona),\n");
    fprintf (h,"3 aiuto fisico (2 persone), 8 attività mai eseguita\n");
    fprintf (h,"---------------------------------------------------------------------------------------\n");
    fprintf (h,"                                                        A               B\n");
    fprintf (h,"a.Mobilità a letto                                      %d               %d\n",archivio.adl[0][0],archivio.adl[0][1]);
    fprintf (h,"b.Trasferimenti                                         %d               %d\n",archivio.adl[1][0],archivio.adl[1][1]);
    fprintf (h,"h.Mangiare                                              %d               %d\n",archivio.adl[2][0],archivio.adl[2][1]);
    fprintf (h,"i.Eliminazione di feci e urine                          %d               %d\n",archivio.adl[3][0],archivio.adl[3][1]);

    fprintf (h,"\n\n\nH:  CONTINENZA FECALE ED URINARIA - programmi di educazione\nnegli ultimi 7 giorni\n");
    fprintf (h,"---------------------------------------------------------------------------------------\n");
    fprintf (h,"3a.Ospite accompagnato al bagno ad intervalli regolari\n");
    fprintf (h,"in base ad un programma definito--------------------------------------------");
    if (archivio.continenza[0])
    fprintf(h,"SI\n");
    else
    fprintf(h,"NO\n");
    fprintf (h,"\n3b.Programmi di rieducazione vescicale--------------------------------------");
    if (archivio.continenza[1])
    fprintf(h,"SI\n");
    else
    fprintf(h,"NO\n");


    fprintf (h,"\n\n\nI1: DIAGNOSI DI MALATTIA - negli ultimi 14 giorni\n");
    fprintf (h,"Solo malattie in relazione con: ADL, stato cognitivo, umore, comportamento,\n");
    fprintf (h,"terapie mediche, monitoraggio infermieristico, rischio di morte negli ultimi 14 giorni\n");
    fprintf (h,"---------------------------------------------------------------------------------------\n");
    fprintf (h,"\na.Diabete mellito----------------------------------------------------------");
    if (archivio.diagnosi1[0])
    fprintf(h,"SI\n");
    else
    fprintf(h,"NO\n");
    fprintf (h,"r.Afasia ------------------------------------------------------------------");
    if (archivio.diagnosi1[1])
    fprintf(h,"SI\n");
    else
    fprintf(h,"NO\n");
    fprintf (h,"s.Cerebropatia o epilessia (escluse demenze, Alzheimer, ictus)-------------");
    if (archivio.diagnosi1[2])
    fprintf(h,"SI\n");
    else
    fprintf(h,"NO\n");
    fprintf (h,"v.Emiplegia, emiparesi-----------------------------------------------------");
    if (archivio.diagnosi1[3])
    fprintf(h,"SI\n");
    else
    fprintf(h,"NO\n");
    fprintf (h,"w.Sclerosi multipla--------------------------------------------------------");
    if (archivio.diagnosi1[4])
    fprintf(h,"SI\n");
    else
    fprintf(h,"NO\n");
    fprintf (h,"z.Tetraplegia--------------------------------------------------------------");
    if (archivio.diagnosi1[5])
    fprintf(h,"SI\n");
    else
    fprintf(h,"NO\n");

    fprintf (h,"\n\n\nJ1: PROBLEMI DI SALUTE - negli ultimi 7 giorni\n");
    fprintf (h,"---------------------------------------------------------------------------------------\n");
    fprintf (h,"1c.Segni di disidratazione. Almeno 2 dei seguenti indicatori:\n");
    fprintf (h,"\t1)assunzione <2500cc di liquidi/die - 2)segni clinici di disidratazione\n");
    fprintf (h,"\t3)bilancio idrico negativo-----------------------------------------");
    if (archivio.problemi[0])
    fprintf(h,"SI\n");
    else
    fprintf(h,"NO\n");
    fprintf (h,"1e.Episodi psicotici-------------------------------------------------------");
    if (archivio.problemi[1])
    fprintf(h,"SI\n");
    else
    fprintf(h,"NO\n");
    fprintf (h,"1h.Febbre------------------------------------------------------------------");
    if (archivio.problemi[2])
    fprintf(h,"SI\n");
    else
    fprintf(h,"NO\n");
    fprintf (h,"1i.Allucinazioni-----------------------------------------------------------");
    if (archivio.problemi[3])
    fprintf(h,"SI\n");
    else
    fprintf(h,"NO\n");
    fprintf (h,"1j.Emorragie---------------------------------------------------------------");
    if (archivio.problemi[4])
    fprintf(h,"SI\n");
    else
    fprintf(h,"NO\n");
    fprintf (h,"1o.Vomito------------------------------------------------------------------");
    if (archivio.problemi[5])
    fprintf(h,"SI\n");
    else
    fprintf(h,"NO\n");
    fprintf (h,"5c.Malattia terminale con prognosi di 6 mesi o meno------------------------");
    if (archivio.problemi[6])
    fprintf(h,"SI\n");
    else
    fprintf(h,"NO\n");

    fprintf (h,"\n\n\nK:  STATO NUTRIZIONALE\n");
    fprintf (h,"---------------------------------------------------------------------------------------\n\n");
    fprintf (h,"3a.Perdita di peso del 5%% o più negli ultimi 30 giorni----------------------");
    if (archivio.nutrizione[0])
    fprintf(h,"SI");
    else
    fprintf(h,"NO");
    fprintf (h,"\n\to del 10%% o più negli ultimi 180 giorni\n");
    fprintf (h,"5a.Nutrizione parenterale (EV)----------------------------------------------");
    if (archivio.nutrizione[1])
    fprintf(h,"SI");
    else
    fprintf(h,"NO");
    fprintf(h,"\n\n");
    fprintf (h,"5b.Nutrizione enterale via SNG -gastrostomia - PEG - digiunostomia----------");
    if (archivio.nutrizione[2])
    fprintf(h,"SI");
    else
    fprintf(h,"NO");
    fprintf(h,"\n\n");
    fprintf (h,"6a.%%di calorie introdotte tramite nutrizione artificiale--------------------");
    fprintf (h,"%d",archivio.nutrizione[3]);
    fprintf (h,"\n\t0. nulla - 1. 1%%-25%% - 2. 26%%-50%% - 3. 51%%-75%% - 4. 76%%-100%%\n\n");
    fprintf (h,"6a.Quota di fluidi assunti per ev o per sondino negli ultimi 7 gg-----------");
    fprintf (h,"%d",archivio.nutrizione[4]);
    fprintf (h,"\n\t0. nulla - 1. 1-500cc - 2. 501-1000cc - 3. 1001-1500cc\n\t4. 1501-2000cc - 5. più di 2000cc\n\n");

    fprintf (h,"\nM.  CONDIZIONI DELLA CUTE negli ultimi 7 giorni\n");
    fprintf (h,"---------------------------------------------------------------------------------------\n");
    fprintf (h,"1a.Ulcere stadio I  (qualsiasi causa) ---------------------------------%d\n",archivio.cute[0]);
    fprintf (h,"1b.Ulcere stadio II (qualsiasi causa) ---------------------------------%d\n",archivio.cute[1]);
    fprintf (h,"1c.Ulcere stadio III(qualsiasi causa) ---------------------------------%d\n",archivio.cute[2]);
    fprintf (h,"1d.Ulcere stadio IV (qualsiasi causa) ---------------------------------%d\n",archivio.cute[3]);
    fprintf (h,"2a.Stadio raggiunto dall'ulcera da decubito piu' grave-----------------%s\n",romani[archivio.cute[4]]);
    fprintf (h,"4b.Ustioni-------------------------------------------------------------");
    if (archivio.cute[5])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");

    fprintf (h,"4c.Lesioni aperte esclusi rash o tagli (es. ferite cancerose)----------");
    if (archivio.cute[6])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");
    fprintf (h,"4g.Ferite chirurgiche--------------------------------------------------");
    if (archivio.cute[7])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");
    fprintf (h,"5a.Sedie o carrozzine con dispositivo antidecubito---------------------");
    if (archivio.cute[8])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");
    fprintf (h,"5b.Letto attrezzato con dispositivo antidecubito-----------------------");
    if (archivio.cute[9])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");
    fprintf (h,"5c.Programmi di rotazione/ Documentaz. di riposizionamento dell'ospite-");
    if (archivio.cute[10])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");
    fprintf (h,"5d.Terapie nutrizionali o reidratanti per gestire problemi cutanei-----");
    if (archivio.cute[11])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");
    fprintf (h,"5e.Interventi per la cura dell'ulcera (piede compreso)-----------------");
    if (archivio.cute[12])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");
    fprintf (h,"5f.Interventi per la cura della ferita chirurgica----------------------");
    if (archivio.cute[13])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");
    fprintf (h,"5g.Medicazioni (piede escluso)-----------------------------------------");
    if (archivio.cute[14])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");
    fprintf (h,"5h.Applicazione di unguenti/farmaci (compresi oli e creme)-------------");
    if (archivio.cute[15])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");
     fprintf (h,"6b.Piede: infezioni (ad es. celluliti e drenaggi purulenti-------------");
    if (archivio.cute[16])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");
     fprintf (h,"6c.Piede: lesioni aperte (tagli,ulcere,fessure)------------------------");
    if (archivio.cute[17])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");
     fprintf (h,"6f.Piede: medicazioni con o senza applicazione di farmaci topici-------");
    if (archivio.cute[18])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");
    fprintf (h,"\n\n");

    fprintf (h,"N.  ATTIVITÀ negli ultimi 7 giorni\n");
    fprintf(h,"SI: l'ospite è sveglio per la maggior parte del tempo\n");
    fprintf(h,"NO: l'ospite dorme o sonnecchia per più di un'ora\n");

    fprintf (h,"---------------------------------------------------------------------------------------\n");
    fprintf (h,"1a.Mattino (dalle 7 alle 12)-----------------------------------------------");
     if (archivio.attivita[0])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");
     fprintf (h,"1b.Pomeriggio (dalle 13 alle 18)-------------------------------------------");
     if (archivio.attivita[1])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");
    fprintf (h,"1c.Sera (dalle 19 alle 22)-------------------------------------------------");
     if (archivio.attivita[2])
        fprintf(h,"SI\n");
    else
        fprintf(h,"NO\n");

    fprintf (h,"\n\nO.  FARMACI assunti negli ultimi 7 giorni\n");
    fprintf (h,"---------------------------------------------------------------------------------------\n");
    fprintf (h,"3.Iniezioni di qualunque tipo ricevute negli ultimi 7 giorni----------------%d\n\n\n",archivio.iniezioni);

    fprintf (h,"P.  TRATTAMENTI E PROCEDURE SPECIALI o programmi speciali ricevuti negli ultimi 14 giorni\n");
    fprintf (h,"---------------------------------------------------------------------------------------");
    fprintf (h,"\n1A) TRATTAMENTI SPECIALI\n");

    fprintf (h,"\na.Chemioterapia oncologica--------------------------------------------------");
    if (archivio.trattamenti[0])
        fprintf (h,"SI");
    else
        fprintf(h,"NO");
    fprintf (h,"\nb.Dialisi-------------------------------------------------------------------");
    if (archivio.trattamenti[1])
        fprintf (h,"SI");
    else
        fprintf(h,"NO");
     fprintf (h,"\nc.Infusione endovenosa------------------------------------------------------");
    if (archivio.trattamenti[2])
        fprintf (h,"SI");
    else
        fprintf(h,"NO");
     fprintf (h,"\ng.Ossigenoterapia-----------------------------------------------------------");
    if (archivio.trattamenti[3])
        fprintf (h,"SI");
    else
        fprintf(h,"NO");
    fprintf (h,"\nh.Radioterapia--------------------------------------------------------------");
    if (archivio.trattamenti[4])
        fprintf (h,"SI");
    else
        fprintf(h,"NO");
     fprintf (h,"\ni.Aspirazione---------------------------------------------------------------");
    if (archivio.trattamenti[5])
        fprintf (h,"SI");
    else
        fprintf(h,"NO");
     fprintf (h,"\nj.Cura della tracheostomia--------------------------------------------------");
    if (archivio.trattamenti[6])
        fprintf (h,"SI");
    else
        fprintf(h,"NO");
     fprintf (h,"\nk.Trasfusioni---------------------------------------------------------------");
    if (archivio.trattamenti[7])
        fprintf (h,"SI");
    else
        fprintf(h,"NO");
     fprintf (h,"\nl.Respiratore/ventilazione assistita----------------------------------------");
    if (archivio.trattamenti[8])
        fprintf (h,"SI");
    else
        fprintf(h,"NO");
    fprintf(h,"\n\n");

    fprintf (h,"1B) TERAPIE SPECIALI negli ultimi 7 giorni\n");
    fprintf (h,"\t<A> numero giorni di terapia per 15 minuti o più\n");
    fprintf (h,"\t<B> minuti totali di terapia erogati negli ultimi 7 giorni\n");
    fprintf (h,"                                                        A               B\n");
    fprintf (h,"Logoterapia---------------------------------------------%d               %d\n",archivio.terapie[0][0],archivio.terapie[0][1]);
    fprintf (h,"Terapia occupazionale-----------------------------------%d               %d\n",archivio.terapie[1][0],archivio.terapie[1][1]);
    fprintf (h,"Fisioterapia-(recupero funzionale)----------------------%d               %d\n",archivio.terapie[2][0],archivio.terapie[2][1]);
    fprintf (h,"Terapia respiratoria-(anche aerosol eseguiti da inf.)---%d               %d\n",archivio.terapie[3][0],archivio.terapie[3][1]);

    fprintf (h,"\n3) ASSISTENZA RIABILITATIVA INTEGRATIVA\n   numero di giorni, nell'ultima settimana, in cui\n   è stata somministrata per almeno 15 minuti\n");
    fprintf (h,"a.Movimento passivo------------------------------------------------------%d\n",archivio.riabilitazione[0]);
    fprintf (h,"b.Movimento attivo--(escluse attività per gruppi di 5 o più persone)-----%d\n",archivio.riabilitazione[1]);
    fprintf (h,"c.Stecche o rinforzi-----------------------------------------------------%d\n",archivio.riabilitazione[2]);
    fprintf (h,"d.Mobilità a letto-(solo insegnamento)-----------------------------------%d\n",archivio.riabilitazione[3]);
    fprintf (h,"e.Trasferimenti-(solo insegnamento)--------------------------------------%d\n",archivio.riabilitazione[4]);
    fprintf (h,"f.Camminare -(solo insegnamento)-----------------------------------------%d\n",archivio.riabilitazione[5]);
    fprintf (h,"g.Vestirsi o agghindarsi-(solo insegnamento)-----------------------------%d\n",archivio.riabilitazione[6]);
    fprintf (h,"h.Mangiare o inghiottire-(solo insegnamento)-----------------------------%d\n",archivio.riabilitazione[7]);
    fprintf (h,"i.Cura della protesi-(per amputati)--------------------------------------%d\n",archivio.riabilitazione[8]);
    fprintf (h,"j.Comunicare-(solo insegnamento)-----------------------------------------%d\n",archivio.riabilitazione[9]);
    fprintf (h,"\nVISITE MEDICHE\n");
    fprintf (h,"Numero visite mediche negli ultimi 30 giorni (da 1 a 14)-----------------%d\n",archivio.visite);
    fprintf (h,"\nPRESCRIZIONI MEDICHE\n");
    fprintf (h,"Modifiche nelle prescrizioni mediche negli ultimi 30 giorni (da 1 a 14)--%d\n\n\n",archivio.prescrizioni);



    fprintf (h,"I2. DIAGNOSI DI MALATTIA - Malattie psichiatriche - umore negli ultimi 15 giorni\n");
    fprintf (h,"---------------------------------------------------------------------------------------\n");
    fprintf (h,"dd.Ansia-----------------------------------------------------------------");
    if (archivio.diagnosi2[0])
        fprintf (h,"SI\n");
    else
        fprintf (h,"NO\n");
    fprintf (h,"ee.Depressione-----------------------------------------------------------");
    if (archivio.diagnosi2[1])
        fprintf (h,"SI\n");
    else
        fprintf (h,"NO\n");
    fprintf (h,"ff.Malattia bipolare-(maniaco/depressiva)--------------------------------");
    if (archivio.diagnosi2[2])
        fprintf (h,"SI\n");
    else
        fprintf (h,"NO\n");
    fprintf (h,"gg.Schizofrenia----------------------------------------------------------");
    if (archivio.diagnosi2[3])
        fprintf (h,"SI\n");
    else
        fprintf (h,"NO\n");

    fprintf (h,"\n\nJ2. CONDIZIONI DI SALUTE\n");
    fprintf (h,"---------------------------------------------------------------------------------------\n");
    fprintf (h,"4a.Caduto negli ultimi 30 giorni-----------------------------------------");
    if (archivio.incidenti[0])
        fprintf (h,"SI\n");
    else
        fprintf (h,"NO\n");
    fprintf (h,"4b.Caduto negli ultimi 31 - 180 giorni-----------------------------------");
    if (archivio.incidenti[1])
        fprintf (h,"SI\n");
    else
        fprintf (h,"NO\n");
    fprintf (h,"4c.Frattura di femore negli ultimi 180 giorni----------------------------");
    if (archivio.incidenti[1])
        fprintf (h,"SI\n");
    else
        fprintf (h,"NO\n");
    fprintf (h,"4d.Altra frattura negli ultimi 180 giorni--------------------------------");
    if (archivio.incidenti[1])
        fprintf (h,"SI\n");
    else
        fprintf (h,"NO\n");



    fprintf (h,"\n\nM.  CONDIZIONI DELLA CUTE: LESIONI GUARITE NEGLI ULTIMI 90 GIORNI\n");
    fprintf (h,"---------------------------------------------------------------------------------------\n");

    fprintf (h,"3.Storia di ulcere guarite negli ultimi 90 giorni------------------------");
    if (archivio.guarigioni)
        fprintf (h,"SI\n");
    else
        fprintf (h,"NO\n");

    fprintf (h,"\n\nP2. TRATTAMENTI SPECIALI/2\n");
    fprintf (h,"---------------------------------------------------------------------------------------\n");
    fprintf (h,"4.STRUMENTI E MEZZI DI CONTENZIONE negli ultimi 7 giorni\n");
    fprintf (h,"0=non usati;1=usati non quotidianamente;2=usati sempre\n\n");
    fprintf (h,"a.Spondine su entrambi i lati del letto----------------------------------%d\n",archivio.contenzione[0]);
    fprintf (h,"b.Altri tipi di spondine (ad es. su un solo lato)------------------------%d\n",archivio.contenzione[1]);
    fprintf (h,"c.Mezzi di contenzione al tronco-----------------------------------------%d\n",archivio.contenzione[2]);
    fprintf (h,"d.Sedie contenitive (impedimento ad alzarsi)-----------------------------%d\n",archivio.contenzione[3]);
    fprintf (h,"\n5.DEGENZE OSPEDALIERE negli ultimi 90 giorni\n");
    fprintf (h,"Numero ricoveri in ospedale negli ultimi 90 giorni-----------------------%d\n",archivio.degenze);
    fprintf (h,"\n6.VISITE IN PRONTO SOCCORSO negli ultimi 90 giorni\n");
    fprintf (h,"Numero accessi in pronto soccorso negli ultimi 90 giorni-----------------%d\n",archivio.visite);
    fprintf (h,"\n9. ESAMI DI LABORATORIO ANOMALI negli ultimi 90 giorni\n");
    fprintf (h,"Numero esami di laboratorio anomali negli ultimi 90 giorni---------------%d\n\n",archivio.visite);

    char *gruppo;
    gruppo=classif ();

    fprintf (h,"CLASSIFICAZIONE RUG-III = %s",gruppo);
    fprintf (h,"\n\n\nFIRMA DELL'INFERMIERE RESPONSABILE DELLA RACCOLTA DATI\n\n\n\n");
    fprintf (h,"---------------------------------------------");


    /** FINE STAMPA RUG **/











    fclose(h);
}

char *classif (void)

{
    char *codx= malloc (sizeof(char)*4);
    short t=archivio.rug[1];

    switch (archivio.rug[0])
    {
    case (0):
        strcpy (codx,"---");
        break;

    case (1):

        strcpy (codx,"SE ");
        *(codx+2)=48+t;
        break;

    case (2):

        strcpy (codx,"RA ");
        *(codx+2)='@'+t;
        break;

    case (3):

        strcpy (codx,"SS ");
        *(codx+2)='@'+t;
        break;

    case (4):
        *codx='C';
        *(codx+1)='@'+(t+1-((t+1)%2))/2;
        *(codx+2)=(t-1)%2+'1';
        break;

    case (5):
        *codx='I';
        *(codx+1)='@'+(t+1-((t+1)%2))/2;
        *(codx+2)=(t-1)%2+'1';
        break;

    case (6):
        *codx='B';
        *(codx+1)='@'+(t+1-((t+1)%2))/2;
        *(codx+2)=(t-1)%2+'1';
        break;

    case (7):
        *codx='P';
        *(codx+1)='@'+(t+1-((t+1)%2))/2;
        *(codx+2)=(t-1)%2+'1';
        break;







    }

    return (codx);


}

